/**
 * Concierge IA - Sistema de assistência passo a passo para planejamento de viagens
 * Hub IGO Travel
 */

// Estado do assistente
let conciergeState = {
    currentStep: 0,
    totalSteps: 5,
    userSelections: {
        destination: '',
        dates: {
            departure: '',
            return: ''
        },
        travelers: {
            adults: 1,
            children: 0,
            infants: 0
        },
        interests: [],
        budget: '',
        accommodation: ''
    },
    recommendations: []
};

// Configuração dos passos do assistente
const conciergeSteps = [
    {
        id: 'destination',
        title: 'Destino',
        question: 'Para onde você gostaria de viajar?',
        description: 'Escolha seu destino dos sonhos ou deixe que eu sugira opções baseadas nos seus interesses.',
        inputType: 'destination-selector',
        suggestions: ['Toronto', 'Nova York', 'Paris', 'Tóquio', 'Cancún', 'Rio de Janeiro']
    },
    {
        id: 'dates',
        title: 'Datas',
        question: 'Quando você planeja viajar?',
        description: 'Selecione as datas ou período aproximado da sua viagem. Posso sugerir as melhores épocas para visitar seu destino.',
        inputType: 'date-selector',
        suggestions: ['Próximo mês', 'Próximos 3 meses', 'Férias de verão', 'Férias de inverno']
    },
    {
        id: 'travelers',
        title: 'Viajantes',
        question: 'Quem vai viajar com você?',
        description: 'Informe quantas pessoas vão participar da viagem para que eu possa personalizar as recomendações.',
        inputType: 'traveler-counter'
    },
    {
        id: 'interests',
        title: 'Interesses',
        question: 'O que você gostaria de fazer durante a viagem?',
        description: 'Selecione seus interesses para que eu possa recomendar atividades e experiências personalizadas.',
        inputType: 'interest-selector',
        options: [
            { id: 'culture', label: 'Cultura e História', icon: 'museum' },
            { id: 'nature', label: 'Natureza e Aventura', icon: 'mountain' },
            { id: 'gastronomy', label: 'Gastronomia', icon: 'utensils' },
            { id: 'shopping', label: 'Compras', icon: 'shopping-bag' },
            { id: 'nightlife', label: 'Vida Noturna', icon: 'moon' },
            { id: 'relaxation', label: 'Relaxamento', icon: 'spa' },
            { id: 'family', label: 'Atividades Familiares', icon: 'child' },
            { id: 'sports', label: 'Esportes', icon: 'futbol' }
        ]
    },
    {
        id: 'budget',
        title: 'Orçamento',
        question: 'Qual é o seu orçamento aproximado?',
        description: 'Informe seu orçamento para que eu possa recomendar opções adequadas ao seu perfil financeiro.',
        inputType: 'budget-selector',
        options: [
            { id: 'economic', label: 'Econômico', description: 'Opções com melhor custo-benefício' },
            { id: 'comfort', label: 'Conforto', description: 'Equilíbrio entre qualidade e preço' },
            { id: 'premium', label: 'Premium', description: 'Experiências exclusivas e de alto padrão' }
        ]
    }
];

// Inicializa o Concierge IA
function initConcierge() {
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return;

    renderConciergeUI(conciergeContainer);
    attachEventListeners();
}

// Renderiza a interface do Concierge IA
function renderConciergeUI(container) {
    // Cabeçalho do Concierge
    const header = document.createElement('div');
    header.className = 'concierge-header';
    header.innerHTML = `
        <div class="concierge-title">
            <h2><i class="fas fa-robot"></i> Concierge IA</h2>
            <p>Seu assistente pessoal de viagens</p>
        </div>
        <div class="concierge-progress">
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${(conciergeState.currentStep / conciergeState.totalSteps) * 100}%"></div>
            </div>
            <div class="progress-steps">
                <span>Passo ${conciergeState.currentStep + 1} de ${conciergeState.totalSteps}</span>
            </div>
        </div>
    `;
    container.appendChild(header);

    // Conteúdo do passo atual
    const currentStep = conciergeSteps[conciergeState.currentStep];
    const stepContent = document.createElement('div');
    stepContent.className = 'concierge-step';
    stepContent.innerHTML = `
        <div class="step-question">
            <h3>${currentStep.question}</h3>
            <p>${currentStep.description}</p>
        </div>
        <div class="step-input" id="step-input-${currentStep.id}">
            ${renderStepInput(currentStep)}
        </div>
    `;
    container.appendChild(stepContent);

    // Botões de navegação
    const navigation = document.createElement('div');
    navigation.className = 'concierge-navigation';
    navigation.innerHTML = `
        <button class="btn-secondary" id="concierge-back" ${conciergeState.currentStep === 0 ? 'disabled' : ''}>
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
        <button class="btn-primary" id="concierge-next">
            ${conciergeState.currentStep === conciergeState.totalSteps - 1 ? 'Finalizar' : 'Continuar'} <i class="fas fa-arrow-right"></i>
        </button>
    `;
    container.appendChild(navigation);

    // Assistente virtual (chat)
    const assistant = document.createElement('div');
    assistant.className = 'concierge-assistant';
    assistant.innerHTML = `
        <div class="assistant-avatar">
            <i class="fas fa-user-tie"></i>
        </div>
        <div class="assistant-message">
            <p>${getAssistantMessage(currentStep)}</p>
            <div class="assistant-typing">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
            </div>
        </div>
    `;
    container.appendChild(assistant);
}

// Renderiza o input específico para cada passo
function renderStepInput(step) {
    switch (step.inputType) {
        case 'destination-selector':
            return `
                <div class="destination-search">
                    <input type="text" id="destination-input" placeholder="Digite o destino desejado" class="form-control">
                    <div class="destination-suggestions">
                        ${step.suggestions.map(dest => `<div class="suggestion-item" data-value="${dest}">${dest}</div>`).join('')}
                    </div>
                </div>
            `;
        
        case 'date-selector':
            return `
                <div class="date-selector">
                    <div class="date-range">
                        <div class="date-field">
                            <label>Ida</label>
                            <input type="date" id="departure-date" class="form-control">
                        </div>
                        <div class="date-field">
                            <label>Volta</label>
                            <input type="date" id="return-date" class="form-control">
                        </div>
                    </div>
                    <div class="date-suggestions">
                        ${step.suggestions.map(period => `<div class="suggestion-item" data-value="${period}">${period}</div>`).join('')}
                    </div>
                </div>
            `;
        
        case 'traveler-counter':
            return `
                <div class="traveler-counter">
                    <div class="traveler-type">
                        <label>Adultos</label>
                        <div class="counter">
                            <button class="counter-btn minus" data-type="adults">-</button>
                            <span class="counter-value" id="adults-count">1</span>
                            <button class="counter-btn plus" data-type="adults">+</button>
                        </div>
                    </div>
                    <div class="traveler-type">
                        <label>Crianças (2-11 anos)</label>
                        <div class="counter">
                            <button class="counter-btn minus" data-type="children">-</button>
                            <span class="counter-value" id="children-count">0</span>
                            <button class="counter-btn plus" data-type="children">+</button>
                        </div>
                    </div>
                    <div class="traveler-type">
                        <label>Bebês (0-2 anos)</label>
                        <div class="counter">
                            <button class="counter-btn minus" data-type="infants">-</button>
                            <span class="counter-value" id="infants-count">0</span>
                            <button class="counter-btn plus" data-type="infants">+</button>
                        </div>
                    </div>
                </div>
            `;
        
        case 'interest-selector':
            return `
                <div class="interest-selector">
                    ${step.options.map(option => `
                        <div class="interest-option" data-interest="${option.id}">
                            <div class="interest-icon">
                                <i class="fas fa-${option.icon}"></i>
                            </div>
                            <div class="interest-label">${option.label}</div>
                        </div>
                    `).join('')}
                </div>
            `;
        
        case 'budget-selector':
            return `
                <div class="budget-selector">
                    ${step.options.map(option => `
                        <div class="budget-option" data-budget="${option.id}">
                            <div class="budget-header">
                                <h4>${option.label}</h4>
                            </div>
                            <div class="budget-description">
                                <p>${option.description}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        
        default:
            return `<input type="text" class="form-control" placeholder="Digite sua resposta">`;
    }
}

// Obtém mensagem personalizada do assistente para cada passo
function getAssistantMessage(step) {
    switch (step.id) {
        case 'destination':
            return "Olá! Sou seu assistente de viagens pessoal. Para começar, me conte para onde você gostaria de viajar. Posso sugerir destinos populares ou você pode digitar um local específico.";
        
        case 'dates':
            return `Ótima escolha! ${conciergeState.userSelections.destination} é um destino incrível. Agora, vamos definir quando você planeja viajar. Selecione as datas ou escolha um período aproximado.`;
        
        case 'travelers':
            return "Perfeito! Agora me conte quem vai participar desta aventura. Quantos adultos, crianças e bebês vão viajar?";
        
        case 'interests':
            return "Ótimo! Para personalizar ainda mais sua experiência, selecione seus principais interesses. Isso me ajudará a recomendar atividades e atrações que combinam com seu perfil.";
        
        case 'budget':
            return "Estamos quase lá! Por último, me conte qual é seu orçamento aproximado para esta viagem. Isso me ajudará a recomendar opções que se encaixem no seu perfil financeiro.";
        
        default:
            return "Como posso ajudar com sua viagem hoje?";
    }
}

// Anexa event listeners aos elementos interativos
function attachEventListeners() {
    // Botão de próximo passo
    const nextButton = document.getElementById('concierge-next');
    if (nextButton) {
        nextButton.addEventListener('click', () => {
            if (validateCurrentStep()) {
                saveCurrentStepData();
                
                if (conciergeState.currentStep === conciergeState.totalSteps - 1) {
                    // Último passo - gerar recomendações
                    generateRecommendations();
                } else {
                    // Avançar para o próximo passo
                    conciergeState.currentStep++;
                    updateConciergeUI();
                }
            }
        });
    }

    // Botão de passo anterior
    const backButton = document.getElementById('concierge-back');
    if (backButton) {
        backButton.addEventListener('click', () => {
            if (conciergeState.currentStep > 0) {
                conciergeState.currentStep--;
                updateConciergeUI();
            }
        });
    }

    // Event listeners específicos para cada tipo de input
    attachStepSpecificListeners();
}

// Anexa event listeners específicos para o passo atual
function attachStepSpecificListeners() {
    const currentStep = conciergeSteps[conciergeState.currentStep];
    
    switch (currentStep.inputType) {
        case 'destination-selector':
            // Sugestões de destino
            const suggestionItems = document.querySelectorAll('.suggestion-item');
            suggestionItems.forEach(item => {
                item.addEventListener('click', () => {
                    document.getElementById('destination-input').value = item.dataset.value;
                    suggestionItems.forEach(si => si.classList.remove('selected'));
                    item.classList.add('selected');
                });
            });
            break;
        
        case 'traveler-counter':
            // Botões de incremento/decremento
            const counterButtons = document.querySelectorAll('.counter-btn');
            counterButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const type = button.dataset.type;
                    const isPlus = button.classList.contains('plus');
                    const countElement = document.getElementById(`${type}-count`);
                    let count = parseInt(countElement.textContent);
                    
                    if (isPlus) {
                        count++;
                    } else if (count > 0) {
                        count--;
                    }
                    
                    countElement.textContent = count;
                });
            });
            break;
        
        case 'interest-selector':
            // Seleção de interesses
            const interestOptions = document.querySelectorAll('.interest-option');
            interestOptions.forEach(option => {
                option.addEventListener('click', () => {
                    option.classList.toggle('selected');
                });
            });
            break;
        
        case 'budget-selector':
            // Seleção de orçamento
            const budgetOptions = document.querySelectorAll('.budget-option');
            budgetOptions.forEach(option => {
                option.addEventListener('click', () => {
                    budgetOptions.forEach(bo => bo.classList.remove('selected'));
                    option.classList.add('selected');
                });
            });
            break;
    }
}

// Valida os dados do passo atual
function validateCurrentStep() {
    const currentStep = conciergeSteps[conciergeState.currentStep];
    
    switch (currentStep.id) {
        case 'destination':
            const destination = document.getElementById('destination-input').value;
            return destination.trim() !== '';
        
        case 'dates':
            const departureDate = document.getElementById('departure-date').value;
            const returnDate = document.getElementById('return-date').value;
            return departureDate !== '' && returnDate !== '';
        
        case 'travelers':
            const adultsCount = parseInt(document.getElementById('adults-count').textContent);
            return adultsCount > 0;
        
        case 'interests':
            const selectedInterests = document.querySelectorAll('.interest-option.selected');
            return selectedInterests.length > 0;
        
        case 'budget':
            const selectedBudget = document.querySelector('.budget-option.selected');
            return selectedBudget !== null;
        
        default:
            return true;
    }
}

// Salva os dados do passo atual
function saveCurrentStepData() {
    const currentStep = conciergeSteps[conciergeState.currentStep];
    
    switch (currentStep.id) {
        case 'destination':
            conciergeState.userSelections.destination = document.getElementById('destination-input').value;
            break;
        
        case 'dates':
            conciergeState.userSelections.dates.departure = document.getElementById('departure-date').value;
            conciergeState.userSelections.dates.return = document.getElementById('return-date').value;
            break;
        
        case 'travelers':
            conciergeState.userSelections.travelers.adults = parseInt(document.getElementById('adults-count').textContent);
            conciergeState.userSelections.travelers.children = parseInt(document.getElementById('children-count').textContent);
            conciergeState.userSelections.travelers.infants = parseInt(document.getElementById('infants-count').textContent);
            break;
        
        case 'interests':
            const selectedInterests = document.querySelectorAll('.interest-option.selected');
            conciergeState.userSelections.interests = Array.from(selectedInterests).map(el => el.dataset.interest);
            break;
        
        case 'budget':
            const selectedBudget = document.querySelector('.budget-option.selected');
            conciergeState.userSelections.budget = selectedBudget ? selectedBudget.dataset.budget : '';
            break;
    }
}

// Atualiza a interface do Concierge IA
function updateConciergeUI() {
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return;
    
    // Limpa o conteúdo atual
    conciergeContainer.innerHTML = '';
    
    // Renderiza a nova interface
    renderConciergeUI(conciergeContainer);
    
    // Anexa novos event listeners
    attachEventListeners();
}

// Gera recomendações baseadas nas seleções do usuário
function generateRecommendations() {
    // Simula chamada à API de IA
    simulateAIProcessing().then(() => {
        // Gera recomendações baseadas nas seleções do usuário
        const recommendations = generateMockRecommendations();
        conciergeState.recommendations = recommendations;
        
        // Exibe as recomendações
        showRecommendations();
    });
}

// Simula processamento da IA
function simulateAIProcessing() {
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return Promise.resolve();
    
    // Exibe indicador de carregamento
    conciergeContainer.innerHTML = `
        <div class="ai-processing">
            <div class="processing-animation">
                <div class="processing-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="processing-dots">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
            </div>
            <h3>Processando suas preferências</h3>
            <p>Estou analisando milhares de opções para criar recomendações personalizadas para você...</p>
        </div>
    `;
    
    // Simula tempo de processamento
    return new Promise(resolve => {
        setTimeout(resolve, 3000);
    });
}

// Gera recomendações simuladas baseadas nas seleções do usuário
function generateMockRecommendations() {
    const destination = conciergeState.userSelections.destination;
    const budget = conciergeState.userSelections.budget;
    const interests = conciergeState.userSelections.interests;
    
    // Recomendações simuladas
    const recommendations = [
        {
            title: `Pacote ${budget === 'premium' ? 'Premium' : budget === 'comfort' ? 'Conforto' : 'Econômico'} para ${destination}`,
            description: `Experimente o melhor de ${destination} com este pacote personalizado que inclui passagens aéreas, hospedagem e atividades selecionadas com base nos seus interesses.`,
            price: budget === 'premium' ? 12500 : budget === 'comfort' ? 7800 : 4500,
            currency: 'BRL',
            highlights: [
                'Passagens aéreas de ida e volta',
                `Hospedagem em hotel ${budget === 'premium' ? '5 estrelas' : budget === 'comfort' ? '4 estrelas' : '3 estrelas'}`,
                'Transfer aeroporto-hotel-aeroporto',
                'Seguro viagem completo',
                `${budget === 'premium' ? 'Tour privativo' : 'City tour'} pelos principais pontos turísticos`
            ],
            activities: generateActivitiesByInterests(destination, interests)
        },
        {
            title: `Experiência Exclusiva IGO Travel em ${destination}`,
            description: `Uma experiência única em ${destination} com condições especiais da IGO Travel, incluindo benefícios exclusivos e atendimento personalizado.`,
            price: budget === 'premium' ? 14200 : budget === 'comfort' ? 8900 : 5200,
            currency: 'BRL',
            specialCondition: true,
            highlights: [
                'Passagens aéreas de ida e volta em classe executiva',
                `Hospedagem em hotel ${budget === 'premium' ? 'boutique de luxo' : budget === 'comfort' ? '4 estrelas superior' : '3 estrelas premium'}`,
                'Transfer privativo aeroporto-hotel-aeroporto',
                'Seguro viagem premium com cobertura estendida',
                'Concierge exclusivo durante toda a viagem',
                'Experiências gastronômicas selecionadas'
            ],
            activities: generateActivitiesByInterests(destination, interests, true)
        }
    ];
    
    return recommendations;
}

// Gera atividades baseadas nos interesses do usuário
function generateActivitiesByInterests(destination, interests, isSpecial = false) {
    const activities = [];
    
    if (interests.includes('culture')) {
        activities.push(`Visita guiada aos museus e pontos históricos de ${destination}`);
        if (isSpecial) activities.push(`Acesso VIP a exposições exclusivas em ${destination}`);
    }
    
    if (interests.includes('nature')) {
        activities.push(`Passeio pelos parques naturais de ${destination}`);
        if (isSpecial) activities.push(`Experiência exclusiva de ecoturismo em ${destination}`);
    }
    
    if (interests.includes('gastronomy')) {
        activities.push(`Tour gastronômico pelos melhores restaurantes de ${destination}`);
        if (isSpecial) activities.push(`Jantar exclusivo com chef renomado de ${destination}`);
    }
    
    if (interests.includes('shopping')) {
        activities.push(`Passeio pelos principais centros comerciais de ${destination}`);
        if (isSpecial) activities.push(`Serviço de personal shopper nas melhores lojas de ${destination}`);
    }
    
    if (activities.length === 0) {
        activities.push(`City tour pelos principais pontos turísticos de ${destination}`);
        if (isSpecial) activities.push(`Experiências exclusivas selecionadas em ${destination}`);
    }
    
    return activities;
}

// Exibe as recomendações geradas
function showRecommendations() {
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return;
    
    // Cabeçalho das recomendações
    conciergeContainer.innerHTML = `
        <div class="recommendations-header">
            <h2>Recomendações Personalizadas</h2>
            <p>Com base nas suas preferências, preparei estas opções especiais para sua viagem a ${conciergeState.userSelections.destination}.</p>
        </div>
        <div class="recommendations-container" id="recommendations-list"></div>
        <div class="recommendations-actions">
            <button class="btn-secondary" id="restart-concierge">
                <i class="fas fa-redo"></i> Recomeçar
            </button>
            <button class="btn-primary" id="contact-consultant">
                <i class="fas fa-phone"></i> Falar com Consultor
            </button>
        </div>
    `;
    
    // Renderiza cada recomendação
    const recommendationsList = document.getElementById('recommendations-list');
    conciergeState.recommendations.forEach(recommendation => {
        const recommendationCard = document.createElement('div');
        recommendationCard.className = `recommendation-card ${recommendation.specialCondition ? 'special-condition' : ''}`;
        
        recommendationCard.innerHTML = `
            <div class="recommendation-header">
                <h3>${recommendation.title}</h3>
                ${recommendation.specialCondition ? '<span class="special-badge">Condição Especial IGO Travel</span>' : ''}
            </div>
            <div class="recommendation-content">
                <p class="recommendation-description">${recommendation.description}</p>
                <div class="recommendation-price">
                    <span class="price-label">Valor total:</span>
                    <span class="price-value">${formatCurrency(recommendation.price, recommendation.currency)}</span>
                    <span class="price-installment">ou 10x de ${formatCurrency(recommendation.price / 10, recommendation.currency)}</span>
                </div>
                <div class="recommendation-highlights">
                    <h4>Destaques:</h4>
                    <ul>
                        ${recommendation.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
                    </ul>
                </div>
                <div class="recommendation-activities">
                    <h4>Atividades Recomendadas:</h4>
                    <ul>
                        ${recommendation.activities.map(activity => `<li>${activity}</li>`).join('')}
                    </ul>
                </div>
            </div>
            <div class="recommendation-actions">
                <button class="btn-secondary btn-details">Ver Detalhes</button>
                <button class="btn-primary btn-quote">Solicitar Cotação</button>
            </div>
        `;
        
        recommendationsList.appendChild(recommendationCard);
    });
    
    // Anexa event listeners
    document.getElementById('restart-concierge').addEventListener('click', () => {
        conciergeState.currentStep = 0;
        conciergeState.recommendations = [];
        updateConciergeUI();
    });
    
    document.getElementById('contact-consultant').addEventListener('click', () => {
        showContactForm();
    });
    
    document.querySelectorAll('.btn-quote').forEach(button => {
        button.addEventListener('click', (e) => {
            const card = e.target.closest('.recommendation-card');
            const index = Array.from(recommendationsList.children).indexOf(card);
            requestQuotation(conciergeState.recommendations[index]);
        });
    });
    
    document.querySelectorAll('.btn-details').forEach(button => {
        button.addEventListener('click', (e) => {
            const card = e.target.closest('.recommendation-card');
            const index = Array.from(recommendationsList.children).indexOf(card);
            showRecommendationDetails(conciergeState.recommendations[index]);
        });
    });
}

// Formata valor monetário
function formatCurrency(value, currency) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: currency || 'BRL'
    }).format(value);
}

// Exibe formulário de contato
function showContactForm() {
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return;
    
    conciergeContainer.innerHTML = `
        <div class="contact-form-container">
            <h2>Fale com um Consultor</h2>
            <p>Preencha o formulário abaixo para que um de nossos consultores entre em contato com você.</p>
            
            <form id="contact-form" class="contact-form">
                <div class="form-group">
                    <label for="contact-name">Nome completo</label>
                    <input type="text" id="contact-name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contact-email">E-mail</label>
                    <input type="email" id="contact-email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contact-phone">Telefone (WhatsApp)</label>
                    <input type="tel" id="contact-phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contact-message">Mensagem (opcional)</label>
                    <textarea id="contact-message" class="form-control" rows="4"></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-secondary" id="back-to-recommendations">Voltar</button>
                    <button type="submit" class="btn-primary">Enviar</button>
                </div>
            </form>
        </div>
    `;
    
    // Event listeners
    document.getElementById('back-to-recommendations').addEventListener('click', () => {
        showRecommendations();
    });
    
    document.getElementById('contact-form').addEventListener('submit', (e) => {
        e.preventDefault();
        submitContactForm();
    });
}

// Envia formulário de contato
function submitContactForm() {
    // Simula envio do formulário
    const contactForm = document.getElementById('contact-form');
    const formData = new FormData(contactForm);
    
    // Exibe mensagem de sucesso
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return;
    
    conciergeContainer.innerHTML = `
        <div class="success-message">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2>Solicitação Enviada com Sucesso!</h2>
            <p>Obrigado por entrar em contato conosco. Um de nossos consultores entrará em contato com você em breve.</p>
            <button class="btn-primary" id="back-to-home">Voltar para o Início</button>
        </div>
    `;
    
    document.getElementById('back-to-home').addEventListener('click', () => {
        window.location.href = 'index.html';
    });
}

// Solicita cotação para uma recomendação
function requestQuotation(recommendation) {
    // Redireciona para a página de cotação com os parâmetros da recomendação
    window.location.href = `cotacao.html?destination=${encodeURIComponent(conciergeState.userSelections.destination)}&special=${recommendation.specialCondition ? 'true' : 'false'}`;
}

// Exibe detalhes de uma recomendação
function showRecommendationDetails(recommendation) {
    const conciergeContainer = document.getElementById('concierge-container');
    if (!conciergeContainer) return;
    
    conciergeContainer.innerHTML = `
        <div class="recommendation-details">
            <div class="details-header">
                <h2>${recommendation.title}</h2>
                ${recommendation.specialCondition ? '<span class="special-badge">Condição Especial IGO Travel</span>' : ''}
            </div>
            
            <div class="details-content">
                <p class="details-description">${recommendation.description}</p>
                
                <div class="details-price">
                    <span class="price-label">Valor total:</span>
                    <span class="price-value">${formatCurrency(recommendation.price, recommendation.currency)}</span>
                    <span class="price-installment">ou 10x de ${formatCurrency(recommendation.price / 10, recommendation.currency)}</span>
                </div>
                
                <div class="details-section">
                    <h3>Incluso no Pacote:</h3>
                    <ul>
                        ${recommendation.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="details-section">
                    <h3>Atividades Recomendadas:</h3>
                    <ul>
                        ${recommendation.activities.map(activity => `<li>${activity}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="details-section">
                    <h3>Informações Adicionais:</h3>
                    <p>Este pacote foi personalizado com base nas suas preferências para ${conciergeState.userSelections.destination}. Inclui acomodação para ${conciergeState.userSelections.travelers.adults} adulto(s)${conciergeState.userSelections.travelers.children > 0 ? `, ${conciergeState.userSelections.travelers.children} criança(s)` : ''}${conciergeState.userSelections.travelers.infants > 0 ? ` e ${conciergeState.userSelections.travelers.infants} bebê(s)` : ''}.</p>
                    <p>Período da viagem: ${formatDate(conciergeState.userSelections.dates.departure)} a ${formatDate(conciergeState.userSelections.dates.return)}</p>
                    ${recommendation.specialCondition ? '<p class="special-condition-note">Este pacote inclui condições especiais exclusivas da IGO Travel, proporcionando uma experiência diferenciada com benefícios exclusivos.</p>' : ''}
                </div>
            </div>
            
            <div class="details-actions">
                <button class="btn-secondary" id="back-to-recommendations">Voltar</button>
                <button class="btn-primary" id="request-quotation">Solicitar Cotação</button>
            </div>
        </div>
    `;
    
    // Event listeners
    document.getElementById('back-to-recommendations').addEventListener('click', () => {
        showRecommendations();
    });
    
    document.getElementById('request-quotation').addEventListener('click', () => {
        requestQuotation(recommendation);
    });
}

// Formata data
function formatDate(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Inicializa o Concierge IA quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initConcierge();
});
