/**
 * Sistema de Milhas e Ofertas
 * Hub IGO Travel
 */

// Estado do sistema de milhas e ofertas
let milesOffersState = {
    // Programas de milhas suportados
    supportedPrograms: [
        { id: 'smiles', name: 'Smiles (Gol)', icon: 'fa-plane' },
        { id: 'latam', name: 'Latam Pass', icon: 'fa-plane' },
        { id: 'tudoazul', name: 'TudoAzul', icon: 'fa-plane' },
        { id: 'tap', name: 'TAP Miles&Go', icon: 'fa-plane' },
        { id: 'aeroplan', name: 'Air Canada Aeroplan', icon: 'fa-plane' },
        { id: 'united', name: 'United MileagePlus', icon: 'fa-plane' },
        { id: 'american', name: 'AAdvantage (American)', icon: 'fa-plane' },
        { id: 'flyingblue', name: 'Flying Blue (Air France/KLM)', icon: 'fa-plane' },
        { id: 'lufthansa', name: 'Lufthansa Miles & More', icon: 'fa-plane' },
        { id: 'avios', name: 'Avios (Iberia/British/Qatar)', icon: 'fa-plane' }
    ],
    
    // Origens populares
    popularOrigins: [
        { id: 'GRU', name: 'São Paulo (GRU)', country: 'Brasil' },
        { id: 'GIG', name: 'Rio de Janeiro (GIG)', country: 'Brasil' },
        { id: 'BSB', name: 'Brasília (BSB)', country: 'Brasil' },
        { id: 'CNF', name: 'Belo Horizonte (CNF)', country: 'Brasil' },
        { id: 'SSA', name: 'Salvador (SSA)', country: 'Brasil' },
        { id: 'REC', name: 'Recife (REC)', country: 'Brasil' },
        { id: 'POA', name: 'Porto Alegre (POA)', country: 'Brasil' },
        { id: 'YYZ', name: 'Toronto (YYZ)', country: 'Canadá' }
    ],
    
    // Destinos populares
    popularDestinations: [
        { id: 'CUN', name: 'Cancún', country: 'México', image: 'https://via.placeholder.com/300x200?text=Cancun' },
        { id: 'MIA', name: 'Miami', country: 'Estados Unidos', image: 'https://via.placeholder.com/300x200?text=Miami' },
        { id: 'LIS', name: 'Lisboa', country: 'Portugal', image: 'https://via.placeholder.com/300x200?text=Lisboa' },
        { id: 'MAD', name: 'Madri', country: 'Espanha', image: 'https://via.placeholder.com/300x200?text=Madri' },
        { id: 'CDG', name: 'Paris', country: 'França', image: 'https://via.placeholder.com/300x200?text=Paris' },
        { id: 'FCO', name: 'Roma', country: 'Itália', image: 'https://via.placeholder.com/300x200?text=Roma' },
        { id: 'JFK', name: 'Nova York', country: 'Estados Unidos', image: 'https://via.placeholder.com/300x200?text=Nova+York' },
        { id: 'YYZ', name: 'Toronto', country: 'Canadá', image: 'https://via.placeholder.com/300x200?text=Toronto' }
    ],
    
    // Ofertas de milhas (simulação de dados do Seat.Aero)
    milesOffers: [
        {
            id: 'offer-1',
            origin: 'GRU',
            destination: 'CUN',
            program: 'smiles',
            airline: 'GOL',
            miles: 29000,
            cashPrice: 1945.00,
            taxes: 120.00,
            currency: 'BRL',
            dates: '15/12/2025 - 22/12/2025',
            roundtrip: true,
            link: '#',
            recommendation: 'miles'
        },
        {
            id: 'offer-2',
            origin: 'GRU',
            destination: 'MIA',
            program: 'latam',
            airline: 'LATAM',
            miles: 35000,
            cashPrice: 2350.00,
            taxes: 180.00,
            currency: 'BRL',
            dates: '10/01/2026 - 20/01/2026',
            roundtrip: true,
            link: '#',
            recommendation: 'miles'
        },
        {
            id: 'offer-3',
            origin: 'GIG',
            destination: 'LIS',
            program: 'tap',
            airline: 'TAP',
            miles: 45000,
            cashPrice: 3200.00,
            taxes: 350.00,
            currency: 'BRL',
            dates: '05/02/2026 - 19/02/2026',
            roundtrip: true,
            link: '#',
            recommendation: 'miles'
        },
        {
            id: 'offer-4',
            origin: 'YYZ',
            destination: 'GRU',
            program: 'aeroplan',
            airline: 'Air Canada',
            miles: 50000,
            cashPrice: 1200.00,
            taxes: 250.00,
            currency: 'CAD',
            dates: '20/03/2026 - 05/04/2026',
            roundtrip: true,
            link: '#',
            recommendation: 'miles'
        }
    ],
    
    // Ofertas de hotéis com milhas
    hotelOffers: [
        {
            id: 'hotel-1',
            name: 'Grand Oasis Cancun',
            location: 'Cancún, México',
            program: 'smiles',
            miles: 48000,
            cashPrice: 980.00,
            currency: 'BRL',
            perNight: true,
            dates: '15/12/2025 - 22/12/2025',
            image: 'https://via.placeholder.com/300x200?text=Grand+Oasis+Cancun',
            link: '#',
            recommendation: 'cash'
        },
        {
            id: 'hotel-2',
            name: 'Fontainebleau Miami Beach',
            location: 'Miami, Estados Unidos',
            program: 'latam',
            miles: 65000,
            cashPrice: 1250.00,
            currency: 'BRL',
            perNight: true,
            dates: '10/01/2026 - 20/01/2026',
            image: 'https://via.placeholder.com/300x200?text=Fontainebleau+Miami',
            link: '#',
            recommendation: 'miles'
        }
    ],
    
    // Ofertas de aluguel de carros com milhas
    carRentalOffers: [
        {
            id: 'car-1',
            company: 'Localiza',
            location: 'Cancún, México',
            carType: 'Econômico',
            program: 'smiles',
            miles: 15000,
            cashPrice: 350.00,
            currency: 'BRL',
            perDay: true,
            dates: '15/12/2025 - 22/12/2025',
            image: 'https://via.placeholder.com/300x200?text=Localiza+Cancun',
            link: '#',
            recommendation: 'cash'
        },
        {
            id: 'car-2',
            company: 'Hertz',
            location: 'Miami, Estados Unidos',
            carType: 'SUV',
            program: 'tudoazul',
            miles: 25000,
            cashPrice: 500.00,
            currency: 'BRL',
            perDay: true,
            dates: '10/01/2026 - 20/01/2026',
            image: 'https://via.placeholder.com/300x200?text=Hertz+Miami',
            link: '#',
            recommendation: 'miles'
        }
    ],
    
    // Pacotes completos com milhas
    packageOffers: [
        {
            id: 'package-1',
            name: 'Cancún All Inclusive',
            description: 'Voo + Hotel All Inclusive + Transfer',
            location: 'Cancún, México',
            hotel: 'All Ritmo Resort',
            program: 'smiles',
            airline: 'GOL',
            miles: 85000,
            cashPrice: 3500.00,
            taxes: 250.00,
            currency: 'BRL',
            dates: '15/12/2025 - 22/12/2025',
            image: 'https://via.placeholder.com/300x200?text=Cancun+All+Inclusive',
            link: '#',
            recommendation: 'miles',
            includes: ['Voo', 'Hotel', 'Transfer', 'Alimentação']
        },
        {
            id: 'package-2',
            name: 'Miami Experience',
            description: 'Voo + Hotel + Aluguel de Carro',
            location: 'Miami, Estados Unidos',
            hotel: 'Fontainebleau Miami Beach',
            program: 'latam',
            airline: 'LATAM',
            miles: 120000,
            cashPrice: 4800.00,
            taxes: 350.00,
            currency: 'BRL',
            dates: '10/01/2026 - 20/01/2026',
            image: 'https://via.placeholder.com/300x200?text=Miami+Experience',
            link: '#',
            recommendation: 'miles',
            includes: ['Voo', 'Hotel', 'Carro']
        }
    ],
    
    // Rotas populares com recomendações
    popularRoutes: [
        {
            origin: 'GRU',
            destination: 'CUN',
            bestProgram: 'smiles',
            averageMiles: 29000,
            averageTaxes: 120.00,
            averageCashPrice: 1945.00,
            currency: 'BRL',
            recommendation: 'miles'
        },
        {
            origin: 'GRU',
            destination: 'MIA',
            bestProgram: 'latam',
            averageMiles: 35000,
            averageTaxes: 180.00,
            averageCashPrice: 2350.00,
            currency: 'BRL',
            recommendation: 'miles'
        },
        {
            origin: 'GIG',
            destination: 'LIS',
            bestProgram: 'tap',
            averageMiles: 45000,
            averageTaxes: 350.00,
            averageCashPrice: 3200.00,
            currency: 'BRL',
            recommendation: 'miles'
        },
        {
            origin: 'YYZ',
            destination: 'GRU',
            bestProgram: 'aeroplan',
            averageMiles: 50000,
            averageTaxes: 250.00,
            averageCashPrice: 1200.00,
            currency: 'CAD',
            recommendation: 'miles'
        }
    ],
    
    // Configurações do usuário
    userSettings: {
        preferredCurrency: 'BRL',
        preferredPrograms: ['smiles', 'latam', 'tap'],
        preferredOrigin: 'GRU',
        showPriceInMiles: true,
        showPriceInCash: true
    }
};

// Inicializa o sistema de milhas e ofertas
function initMilesOffersSystem() {
    // Renderiza a interface principal
    renderMilesOffersUI();
    
    // Anexa event listeners
    attachMilesOffersEventListeners();
}

// Renderiza a interface principal do sistema de milhas e ofertas
function renderMilesOffersUI() {
    const container = document.getElementById('miles-offers-container');
    if (!container) return;
    
    // Limpa o container
    container.innerHTML = '';
    
    // Adiciona o cabeçalho
    const header = document.createElement('div');
    header.className = 'miles-offers-header';
    header.innerHTML = `
        <div class="section-title">
            <h2><i class="fas fa-plane-departure"></i> Milhas & Ofertas IGo</h2>
            <p>Compare preços em milhas e dinheiro, encontre as melhores ofertas</p>
        </div>
    `;
    container.appendChild(header);
    
    // Adiciona o formulário de busca
    const searchForm = document.createElement('div');
    searchForm.className = 'miles-search-form';
    searchForm.innerHTML = `
        <div class="form-row">
            <div class="form-group">
                <label for="origin-select">Origem</label>
                <select id="origin-select" class="form-control">
                    <option value="">Selecione a origem</option>
                    ${milesOffersState.popularOrigins.map(origin => 
                        `<option value="${origin.id}">${origin.name}</option>`
                    ).join('')}
                </select>
            </div>
            
            <div class="form-group">
                <label for="destination-select">Destino</label>
                <select id="destination-select" class="form-control">
                    <option value="">Selecione o destino</option>
                    ${milesOffersState.popularDestinations.map(destination => 
                        `<option value="${destination.id}">${destination.name}, ${destination.country}</option>`
                    ).join('')}
                </select>
            </div>
            
            <div class="form-group">
                <label for="program-select">Programa de Milhas</label>
                <select id="program-select" class="form-control">
                    <option value="">Todos os programas</option>
                    ${milesOffersState.supportedPrograms.map(program => 
                        `<option value="${program.id}">${program.name}</option>`
                    ).join('')}
                </select>
            </div>
            
            <div class="form-group">
                <label>&nbsp;</label>
                <button id="search-miles-button" class="btn-primary">
                    <i class="fas fa-search"></i> Buscar Ofertas
                </button>
            </div>
        </div>
        
        <div class="search-options">
            <div class="display-options">
                <span>Exibir preços em:</span>
                <label class="checkbox-label">
                    <input type="checkbox" id="show-miles" checked> Milhas
                </label>
                <label class="checkbox-label">
                    <input type="checkbox" id="show-cash" checked> Dinheiro
                </label>
            </div>
            
            <button id="random-destination-button" class="btn-secondary">
                <i class="fas fa-random"></i> Destino Aleatório
            </button>
        </div>
    `;
    container.appendChild(searchForm);
    
    // Adiciona as abas de categorias
    const categoryTabs = document.createElement('div');
    categoryTabs.className = 'miles-category-tabs';
    categoryTabs.innerHTML = `
        <div class="tab active" data-category="flights">
            <i class="fas fa-plane"></i> Voos
        </div>
        <div class="tab" data-category="hotels">
            <i class="fas fa-hotel"></i> Hotéis
        </div>
        <div class="tab" data-category="cars">
            <i class="fas fa-car"></i> Carros
        </div>
        <div class="tab" data-category="packages">
            <i class="fas fa-suitcase"></i> Pacotes
        </div>
    `;
    container.appendChild(categoryTabs);
    
    // Adiciona o container de resultados
    const resultsContainer = document.createElement('div');
    resultsContainer.className = 'miles-results-container';
    resultsContainer.id = 'miles-results';
    container.appendChild(resultsContainer);
    
    // Renderiza os resultados iniciais (voos)
    renderMilesResults('flights');
}

// Renderiza os resultados de busca por categoria
function renderMilesResults(category) {
    const resultsContainer = document.getElementById('miles-results');
    if (!resultsContainer) return;
    
    // Limpa o container
    resultsContainer.innerHTML = '';
    
    // Determina quais dados mostrar com base na categoria
    let dataToShow = [];
    let emptyMessage = '';
    
    switch (category) {
        case 'flights':
            dataToShow = milesOffersState.milesOffers;
            emptyMessage = 'Nenhuma oferta de voo encontrada. Tente outros filtros.';
            break;
        case 'hotels':
            dataToShow = milesOffersState.hotelOffers;
            emptyMessage = 'Nenhuma oferta de hotel encontrada. Tente outros filtros.';
            break;
        case 'cars':
            dataToShow = milesOffersState.carRentalOffers;
            emptyMessage = 'Nenhuma oferta de aluguel de carro encontrada. Tente outros filtros.';
            break;
        case 'packages':
            dataToShow = milesOffersState.packageOffers;
            emptyMessage = 'Nenhuma oferta de pacote encontrada. Tente outros filtros.';
            break;
        default:
            dataToShow = milesOffersState.milesOffers;
            emptyMessage = 'Nenhuma oferta encontrada. Tente outros filtros.';
    }
    
    // Verifica se há resultados
    if (dataToShow.length === 0) {
        resultsContainer.innerHTML = `
            <div class="empty-results">
                <div class="empty-icon"><i class="fas fa-search"></i></div>
                <p>${emptyMessage}</p>
            </div>
        `;
        return;
    }
    
    // Renderiza os resultados com base na categoria
    switch (category) {
        case 'flights':
            renderFlightResults(dataToShow, resultsContainer);
            break;
        case 'hotels':
            renderHotelResults(dataToShow, resultsContainer);
            break;
        case 'cars':
            renderCarResults(dataToShow, resultsContainer);
            break;
        case 'packages':
            renderPackageResults(dataToShow, resultsContainer);
            break;
        default:
            renderFlightResults(dataToShow, resultsContainer);
    }
}

// Renderiza resultados de voos
function renderFlightResults(flights, container) {
    flights.forEach(flight => {
        const flightCard = document.createElement('div');
        flightCard.className = `miles-card flight-card ${flight.recommendation === 'miles' ? 'recommend-miles' : 'recommend-cash'}`;
        flightCard.innerHTML = `
            <div class="card-header">
                <div class="route">
                    <div class="origin">${flight.origin}</div>
                    <div class="route-arrow"><i class="fas fa-long-arrow-alt-right"></i></div>
                    <div class="destination">${flight.destination}</div>
                </div>
                <div class="airline-program">
                    <div class="airline">${flight.airline}</div>
                    <div class="program">${getProgramName(flight.program)}</div>
                </div>
            </div>
            
            <div class="card-body">
                <div class="card-details">
                    <div class="dates">
                        <i class="far fa-calendar-alt"></i> ${flight.dates}
                    </div>
                    <div class="trip-type">
                        ${flight.roundtrip ? '<i class="fas fa-exchange-alt"></i> Ida e volta' : '<i class="fas fa-arrow-right"></i> Somente ida'}
                    </div>
                </div>
                
                <div class="price-comparison">
                    <div class="miles-price">
                        <div class="price-label">Milhas:</div>
                        <div class="price-value">${formatNumber(flight.miles)} <span class="miles-text">milhas</span></div>
                        <div class="taxes">+ ${formatCurrency(flight.taxes, flight.currency)} (taxas)</div>
                    </div>
                    
                    <div class="cash-price">
                        <div class="price-label">Dinheiro:</div>
                        <div class="price-value">${formatCurrency(flight.cashPrice, flight.currency)}</div>
                    </div>
                </div>
                
                <div class="recommendation">
                    <div class="recommendation-badge ${flight.recommendation === 'miles' ? 'miles' : 'cash'}">
                        <i class="fas ${flight.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                        Melhor com ${flight.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                    </div>
                </div>
            </div>
            
            <div class="card-actions">
                <button class="btn-secondary btn-sm view-details-btn" data-id="${flight.id}" data-type="flight">
                    <i class="fas fa-info-circle"></i> Ver Detalhes
                </button>
                <button class="btn-primary btn-sm book-btn" data-id="${flight.id}" data-type="flight">
                    <i class="fas fa-check-circle"></i> Reservar
                </button>
                <button class="btn-secondary btn-sm share-btn" data-id="${flight.id}" data-type="flight">
                    <i class="fas fa-share-alt"></i> Compartilhar
                </button>
            </div>
        `;
        container.appendChild(flightCard);
    });
}

// Renderiza resultados de hotéis
function renderHotelResults(hotels, container) {
    hotels.forEach(hotel => {
        const hotelCard = document.createElement('div');
        hotelCard.className = `miles-card hotel-card ${hotel.recommendation === 'miles' ? 'recommend-miles' : 'recommend-cash'}`;
        hotelCard.innerHTML = `
            <div class="card-image">
                <img src="${hotel.image}" alt="${hotel.name}">
            </div>
            
            <div class="card-header">
                <div class="hotel-name">${hotel.name}</div>
                <div class="hotel-location">
                    <i class="fas fa-map-marker-alt"></i> ${hotel.location}
                </div>
            </div>
            
            <div class="card-body">
                <div class="card-details">
                    <div class="dates">
                        <i class="far fa-calendar-alt"></i> ${hotel.dates}
                    </div>
                    <div class="program">
                        <i class="fas fa-award"></i> ${getProgramName(hotel.program)}
                    </div>
                </div>
                
                <div class="price-comparison">
                    <div class="miles-price">
                        <div class="price-label">Milhas:</div>
                        <div class="price-value">${formatNumber(hotel.miles)} <span class="miles-text">milhas</span></div>
                        <div class="per-night">${hotel.perNight ? 'por noite' : 'total'}</div>
                    </div>
                    
                    <div class="cash-price">
                        <div class="price-label">Dinheiro:</div>
                        <div class="price-value">${formatCurrency(hotel.cashPrice, hotel.currency)}</div>
                        <div class="per-night">${hotel.perNight ? 'por noite' : 'total'}</div>
                    </div>
                </div>
                
                <div class="recommendation">
                    <div class="recommendation-badge ${hotel.recommendation === 'miles' ? 'miles' : 'cash'}">
                        <i class="fas ${hotel.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                        Melhor com ${hotel.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                    </div>
                </div>
            </div>
            
            <div class="card-actions">
                <button class="btn-secondary btn-sm view-details-btn" data-id="${hotel.id}" data-type="hotel">
                    <i class="fas fa-info-circle"></i> Ver Detalhes
                </button>
                <button class="btn-primary btn-sm book-btn" data-id="${hotel.id}" data-type="hotel">
                    <i class="fas fa-check-circle"></i> Reservar
                </button>
                <button class="btn-secondary btn-sm share-btn" data-id="${hotel.id}" data-type="hotel">
                    <i class="fas fa-share-alt"></i> Compartilhar
                </button>
            </div>
        `;
        container.appendChild(hotelCard);
    });
}

// Renderiza resultados de aluguel de carros
function renderCarResults(cars, container) {
    cars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = `miles-card car-card ${car.recommendation === 'miles' ? 'recommend-miles' : 'recommend-cash'}`;
        carCard.innerHTML = `
            <div class="card-image">
                <img src="${car.image}" alt="${car.company} - ${car.carType}">
            </div>
            
            <div class="card-header">
                <div class="car-company">${car.company}</div>
                <div class="car-type">${car.carType}</div>
            </div>
            
            <div class="card-body">
                <div class="card-details">
                    <div class="car-location">
                        <i class="fas fa-map-marker-alt"></i> ${car.location}
                    </div>
                    <div class="dates">
                        <i class="far fa-calendar-alt"></i> ${car.dates}
                    </div>
                    <div class="program">
                        <i class="fas fa-award"></i> ${getProgramName(car.program)}
                    </div>
                </div>
                
                <div class="price-comparison">
                    <div class="miles-price">
                        <div class="price-label">Milhas:</div>
                        <div class="price-value">${formatNumber(car.miles)} <span class="miles-text">milhas</span></div>
                        <div class="per-day">${car.perDay ? 'por dia' : 'total'}</div>
                    </div>
                    
                    <div class="cash-price">
                        <div class="price-label">Dinheiro:</div>
                        <div class="price-value">${formatCurrency(car.cashPrice, car.currency)}</div>
                        <div class="per-day">${car.perDay ? 'por dia' : 'total'}</div>
                    </div>
                </div>
                
                <div class="recommendation">
                    <div class="recommendation-badge ${car.recommendation === 'miles' ? 'miles' : 'cash'}">
                        <i class="fas ${car.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                        Melhor com ${car.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                    </div>
                </div>
            </div>
            
            <div class="card-actions">
                <button class="btn-secondary btn-sm view-details-btn" data-id="${car.id}" data-type="car">
                    <i class="fas fa-info-circle"></i> Ver Detalhes
                </button>
                <button class="btn-primary btn-sm book-btn" data-id="${car.id}" data-type="car">
                    <i class="fas fa-check-circle"></i> Reservar
                </button>
                <button class="btn-secondary btn-sm share-btn" data-id="${car.id}" data-type="car">
                    <i class="fas fa-share-alt"></i> Compartilhar
                </button>
            </div>
        `;
        container.appendChild(carCard);
    });
}

// Renderiza resultados de pacotes
function renderPackageResults(packages, container) {
    packages.forEach(pkg => {
        const packageCard = document.createElement('div');
        packageCard.className = `miles-card package-card ${pkg.recommendation === 'miles' ? 'recommend-miles' : 'recommend-cash'}`;
        packageCard.innerHTML = `
            <div class="card-image">
                <img src="${pkg.image}" alt="${pkg.name}">
                <div class="package-badge">Pacote Completo</div>
            </div>
            
            <div class="card-header">
                <div class="package-name">${pkg.name}</div>
                <div class="package-location">
                    <i class="fas fa-map-marker-alt"></i> ${pkg.location}
                </div>
            </div>
            
            <div class="card-body">
                <div class="card-details">
                    <div class="dates">
                        <i class="far fa-calendar-alt"></i> ${pkg.dates}
                    </div>
                    <div class="program">
                        <i class="fas fa-award"></i> ${getProgramName(pkg.program)}
                    </div>
                    <div class="airline">
                        <i class="fas fa-plane"></i> ${pkg.airline}
                    </div>
                </div>
                
                <div class="package-includes">
                    ${pkg.includes.map(item => `
                        <div class="include-item">
                            <i class="fas ${getIncludeIcon(item)}"></i> ${item}
                        </div>
                    `).join('')}
                </div>
                
                <div class="price-comparison">
                    <div class="miles-price">
                        <div class="price-label">Milhas:</div>
                        <div class="price-value">${formatNumber(pkg.miles)} <span class="miles-text">milhas</span></div>
                        <div class="taxes">+ ${formatCurrency(pkg.taxes, pkg.currency)} (taxas)</div>
                    </div>
                    
                    <div class="cash-price">
                        <div class="price-label">Dinheiro:</div>
                        <div class="price-value">${formatCurrency(pkg.cashPrice, pkg.currency)}</div>
                    </div>
                </div>
                
                <div class="recommendation">
                    <div class="recommendation-badge ${pkg.recommendation === 'miles' ? 'miles' : 'cash'}">
                        <i class="fas ${pkg.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                        Melhor com ${pkg.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                    </div>
                </div>
            </div>
            
            <div class="card-actions">
                <button class="btn-secondary btn-sm view-details-btn" data-id="${pkg.id}" data-type="package">
                    <i class="fas fa-info-circle"></i> Ver Detalhes
                </button>
                <button class="btn-primary btn-sm book-btn" data-id="${pkg.id}" data-type="package">
                    <i class="fas fa-check-circle"></i> Reservar
                </button>
                <button class="btn-secondary btn-sm share-btn" data-id="${pkg.id}" data-type="package">
                    <i class="fas fa-share-alt"></i> Compartilhar
                </button>
            </div>
        `;
        container.appendChild(packageCard);
    });
}

// Anexa event listeners aos elementos interativos
function attachMilesOffersEventListeners() {
    // Event listener para as abas de categorias
    const categoryTabs = document.querySelectorAll('.miles-category-tabs .tab');
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove a classe active de todas as abas
            categoryTabs.forEach(t => t.classList.remove('active'));
            
            // Adiciona a classe active à aba clicada
            tab.classList.add('active');
            
            // Renderiza os resultados da categoria selecionada
            const category = tab.dataset.category;
            renderMilesResults(category);
        });
    });
    
    // Event listener para o botão de busca
    const searchButton = document.getElementById('search-miles-button');
    if (searchButton) {
        searchButton.addEventListener('click', () => {
            // Simula uma busca (em uma implementação real, isso faria uma chamada à API)
            const originSelect = document.getElementById('origin-select');
            const destinationSelect = document.getElementById('destination-select');
            const programSelect = document.getElementById('program-select');
            
            // Exibe uma mensagem de busca
            showSearchingMessage();
            
            // Simula um tempo de processamento
            setTimeout(() => {
                // Renderiza os resultados da categoria ativa
                const activeTab = document.querySelector('.miles-category-tabs .tab.active');
                if (activeTab) {
                    const category = activeTab.dataset.category;
                    renderMilesResults(category);
                }
                
                // Exibe uma sugestão inteligente se origem e destino estiverem selecionados
                if (originSelect.value && destinationSelect.value) {
                    showIntelligentSuggestion(originSelect.value, destinationSelect.value);
                }
            }, 1500);
        });
    }
    
    // Event listener para o botão de destino aleatório
    const randomButton = document.getElementById('random-destination-button');
    if (randomButton) {
        randomButton.addEventListener('click', () => {
            // Seleciona um destino aleatório
            const destinations = milesOffersState.popularDestinations;
            const randomIndex = Math.floor(Math.random() * destinations.length);
            const randomDestination = destinations[randomIndex];
            
            // Atualiza o select de destino
            const destinationSelect = document.getElementById('destination-select');
            if (destinationSelect) {
                destinationSelect.value = randomDestination.id;
            }
            
            // Simula um clique no botão de busca
            const searchButton = document.getElementById('search-miles-button');
            if (searchButton) {
                searchButton.click();
            }
        });
    }
    
    // Event listeners para os botões de ação dos cards (delegação de eventos)
    document.addEventListener('click', (event) => {
        // Botão Ver Detalhes
        if (event.target.closest('.view-details-btn')) {
            const button = event.target.closest('.view-details-btn');
            const id = button.dataset.id;
            const type = button.dataset.type;
            showDetailsModal(id, type);
        }
        
        // Botão Reservar
        if (event.target.closest('.book-btn')) {
            const button = event.target.closest('.book-btn');
            const id = button.dataset.id;
            const type = button.dataset.type;
            showBookingModal(id, type);
        }
        
        // Botão Compartilhar
        if (event.target.closest('.share-btn')) {
            const button = event.target.closest('.share-btn');
            const id = button.dataset.id;
            const type = button.dataset.type;
            showShareModal(id, type);
        }
    });
    
    // Event listeners para as opções de exibição
    const showMilesCheckbox = document.getElementById('show-miles');
    const showCashCheckbox = document.getElementById('show-cash');
    
    if (showMilesCheckbox) {
        showMilesCheckbox.addEventListener('change', () => {
            milesOffersState.userSettings.showPriceInMiles = showMilesCheckbox.checked;
            updatePriceDisplay();
        });
    }
    
    if (showCashCheckbox) {
        showCashCheckbox.addEventListener('change', () => {
            milesOffersState.userSettings.showPriceInCash = showCashCheckbox.checked;
            updatePriceDisplay();
        });
    }
}

// Atualiza a exibição de preços com base nas preferências do usuário
function updatePriceDisplay() {
    const milesElements = document.querySelectorAll('.miles-price');
    const cashElements = document.querySelectorAll('.cash-price');
    
    milesElements.forEach(element => {
        element.style.display = milesOffersState.userSettings.showPriceInMiles ? 'block' : 'none';
    });
    
    cashElements.forEach(element => {
        element.style.display = milesOffersState.userSettings.showPriceInCash ? 'block' : 'none';
    });
}

// Exibe uma mensagem de busca
function showSearchingMessage() {
    const resultsContainer = document.getElementById('miles-results');
    if (!resultsContainer) return;
    
    resultsContainer.innerHTML = `
        <div class="searching-message">
            <div class="searching-spinner"></div>
            <p>Buscando as melhores ofertas em milhas e dinheiro...</p>
        </div>
    `;
}

// Exibe uma sugestão inteligente com base na rota
function showIntelligentSuggestion(origin, destination) {
    // Busca uma rota correspondente
    const route = milesOffersState.popularRoutes.find(r => 
        r.origin === origin && r.destination === destination
    );
    
    // Se não encontrar uma rota correspondente, não exibe sugestão
    if (!route) return;
    
    // Cria o elemento de sugestão
    const suggestionElement = document.createElement('div');
    suggestionElement.className = 'intelligent-suggestion';
    suggestionElement.innerHTML = `
        <div class="suggestion-header">
            <div class="suggestion-title">
                <i class="fas fa-lightbulb"></i> Sugestão IGo Travel
            </div>
            <button class="suggestion-close">&times;</button>
        </div>
        
        <div class="suggestion-content">
            <div class="suggestion-route">
                <div class="origin">${origin}</div>
                <div class="route-arrow"><i class="fas fa-long-arrow-alt-right"></i></div>
                <div class="destination">${destination}</div>
            </div>
            
            <div class="suggestion-recommendation">
                <div class="recommendation-badge ${route.recommendation === 'miles' ? 'miles' : 'cash'}">
                    <i class="fas ${route.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                    Melhor com ${route.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                </div>
                
                <div class="recommendation-details">
                    ${route.recommendation === 'miles' ? `
                        <p>Use <strong>${getProgramName(route.bestProgram)}</strong> para este trecho</p>
                        <p>Média: <strong>${formatNumber(route.averageMiles)} milhas</strong> + ${formatCurrency(route.averageTaxes, route.currency)}</p>
                        <p>Valor em dinheiro: ${formatCurrency(route.averageCashPrice, route.currency)}</p>
                    ` : `
                        <p>Melhor pagar em dinheiro: <strong>${formatCurrency(route.averageCashPrice, route.currency)}</strong></p>
                        <p>Valor em milhas: ${formatNumber(route.averageMiles)} + ${formatCurrency(route.averageTaxes, route.currency)}</p>
                    `}
                </div>
            </div>
            
            <div class="suggestion-actions">
                <button class="btn-secondary btn-sm" id="view-options-btn">
                    <i class="fas fa-list"></i> Ver Opções
                </button>
                <button class="btn-primary btn-sm" id="book-miles-btn">
                    <i class="fas fa-check-circle"></i> Reservar com Milhas
                </button>
                <button class="btn-secondary btn-sm" id="view-expedia-btn">
                    <i class="fas fa-external-link-alt"></i> Ver no Expedia
                </button>
            </div>
        </div>
    `;
    
    // Insere a sugestão no início dos resultados
    const resultsContainer = document.getElementById('miles-results');
    if (resultsContainer && resultsContainer.firstChild) {
        resultsContainer.insertBefore(suggestionElement, resultsContainer.firstChild);
    }
    
    // Adiciona event listener para o botão de fechar
    const closeButton = suggestionElement.querySelector('.suggestion-close');
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            suggestionElement.remove();
        });
    }
    
    // Adiciona event listeners para os botões de ação
    const viewOptionsButton = suggestionElement.querySelector('#view-options-btn');
    if (viewOptionsButton) {
        viewOptionsButton.addEventListener('click', () => {
            // Simula um clique na aba de voos
            const flightsTab = document.querySelector('.miles-category-tabs .tab[data-category="flights"]');
            if (flightsTab) {
                flightsTab.click();
            }
        });
    }
    
    const bookMilesButton = suggestionElement.querySelector('#book-miles-btn');
    if (bookMilesButton) {
        bookMilesButton.addEventListener('click', () => {
            // Simula a abertura de um modal de reserva
            showBookingModal(null, 'flight', route);
        });
    }
    
    const viewExpediaButton = suggestionElement.querySelector('#view-expedia-btn');
    if (viewExpediaButton) {
        viewExpediaButton.addEventListener('click', () => {
            // Simula a abertura do Expedia em uma nova aba
            alert('Esta ação abriria o Expedia em uma nova aba com a busca pré-preenchida.');
        });
    }
}

// Exibe modal com detalhes da oferta
function showDetailsModal(id, type) {
    // Busca os dados da oferta com base no ID e tipo
    let offerData = null;
    
    switch (type) {
        case 'flight':
            offerData = milesOffersState.milesOffers.find(offer => offer.id === id);
            break;
        case 'hotel':
            offerData = milesOffersState.hotelOffers.find(hotel => hotel.id === id);
            break;
        case 'car':
            offerData = milesOffersState.carRentalOffers.find(car => car.id === id);
            break;
        case 'package':
            offerData = milesOffersState.packageOffers.find(pkg => pkg.id === id);
            break;
    }
    
    // Se não encontrar dados, exibe um alerta e retorna
    if (!offerData) {
        alert('Detalhes não encontrados para esta oferta.');
        return;
    }
    
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content details-modal';
    
    // Conteúdo do modal com base no tipo
    let modalHTML = '';
    
    switch (type) {
        case 'flight':
            modalHTML = `
                <div class="modal-header">
                    <h3>Detalhes do Voo</h3>
                    <button class="modal-close">&times;</button>
                </div>
                
                <div class="modal-body">
                    <div class="flight-details">
                        <div class="route-details">
                            <div class="route">
                                <div class="origin">${offerData.origin}</div>
                                <div class="route-arrow"><i class="fas fa-long-arrow-alt-right"></i></div>
                                <div class="destination">${offerData.destination}</div>
                            </div>
                            <div class="trip-type">
                                ${offerData.roundtrip ? '<i class="fas fa-exchange-alt"></i> Ida e volta' : '<i class="fas fa-arrow-right"></i> Somente ida'}
                            </div>
                        </div>
                        
                        <div class="airline-details">
                            <div class="airline">
                                <i class="fas fa-plane"></i> ${offerData.airline}
                            </div>
                            <div class="program">
                                <i class="fas fa-award"></i> ${getProgramName(offerData.program)}
                            </div>
                        </div>
                        
                        <div class="dates-details">
                            <div class="dates">
                                <i class="far fa-calendar-alt"></i> ${offerData.dates}
                            </div>
                        </div>
                        
                        <div class="price-details">
                            <div class="price-section">
                                <h4>Preço em Milhas</h4>
                                <div class="price-value">${formatNumber(offerData.miles)} <span class="miles-text">milhas</span></div>
                                <div class="taxes">+ ${formatCurrency(offerData.taxes, offerData.currency)} (taxas)</div>
                            </div>
                            
                            <div class="price-section">
                                <h4>Preço em Dinheiro</h4>
                                <div class="price-value">${formatCurrency(offerData.cashPrice, offerData.currency)}</div>
                            </div>
                        </div>
                        
                        <div class="recommendation-details">
                            <h4>Recomendação IGo Travel</h4>
                            <div class="recommendation-badge ${offerData.recommendation === 'miles' ? 'miles' : 'cash'}">
                                <i class="fas ${offerData.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                                Melhor com ${offerData.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                            </div>
                            <div class="recommendation-explanation">
                                ${offerData.recommendation === 'miles' ? 
                                    `Usando milhas, você economiza aproximadamente ${formatCurrency(offerData.cashPrice - (offerData.taxes || 0), offerData.currency)}.` : 
                                    `Pagando em dinheiro, você economiza suas milhas para um uso mais vantajoso.`
                                }
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn-secondary" id="close-details">Fechar</button>
                    <button class="btn-secondary" id="export-pdf">
                        <i class="fas fa-file-pdf"></i> Exportar PDF
                    </button>
                    <button class="btn-secondary" id="share-whatsapp">
                        <i class="fab fa-whatsapp"></i> Compartilhar
                    </button>
                    <button class="btn-primary" id="book-now">
                        <i class="fas fa-check-circle"></i> Reservar Agora
                    </button>
                </div>
            `;
            break;
            
        case 'hotel':
            modalHTML = `
                <div class="modal-header">
                    <h3>Detalhes do Hotel</h3>
                    <button class="modal-close">&times;</button>
                </div>
                
                <div class="modal-body">
                    <div class="hotel-details">
                        <div class="hotel-image">
                            <img src="${offerData.image}" alt="${offerData.name}">
                        </div>
                        
                        <div class="hotel-info">
                            <h4>${offerData.name}</h4>
                            <div class="hotel-location">
                                <i class="fas fa-map-marker-alt"></i> ${offerData.location}
                            </div>
                        </div>
                        
                        <div class="dates-details">
                            <div class="dates">
                                <i class="far fa-calendar-alt"></i> ${offerData.dates}
                            </div>
                            <div class="program">
                                <i class="fas fa-award"></i> ${getProgramName(offerData.program)}
                            </div>
                        </div>
                        
                        <div class="price-details">
                            <div class="price-section">
                                <h4>Preço em Milhas</h4>
                                <div class="price-value">${formatNumber(offerData.miles)} <span class="miles-text">milhas</span></div>
                                <div class="per-night">${offerData.perNight ? 'por noite' : 'total'}</div>
                            </div>
                            
                            <div class="price-section">
                                <h4>Preço em Dinheiro</h4>
                                <div class="price-value">${formatCurrency(offerData.cashPrice, offerData.currency)}</div>
                                <div class="per-night">${offerData.perNight ? 'por noite' : 'total'}</div>
                            </div>
                        </div>
                        
                        <div class="recommendation-details">
                            <h4>Recomendação IGo Travel</h4>
                            <div class="recommendation-badge ${offerData.recommendation === 'miles' ? 'miles' : 'cash'}">
                                <i class="fas ${offerData.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                                Melhor com ${offerData.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                            </div>
                            <div class="recommendation-explanation">
                                ${offerData.recommendation === 'miles' ? 
                                    `Usando milhas, você economiza aproximadamente ${formatCurrency(offerData.cashPrice, offerData.currency)}.` : 
                                    `Pagando em dinheiro, você economiza suas milhas para um uso mais vantajoso.`
                                }
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn-secondary" id="close-details">Fechar</button>
                    <button class="btn-secondary" id="export-pdf">
                        <i class="fas fa-file-pdf"></i> Exportar PDF
                    </button>
                    <button class="btn-secondary" id="share-whatsapp">
                        <i class="fab fa-whatsapp"></i> Compartilhar
                    </button>
                    <button class="btn-primary" id="book-now">
                        <i class="fas fa-check-circle"></i> Reservar Agora
                    </button>
                </div>
            `;
            break;
            
        case 'car':
            modalHTML = `
                <div class="modal-header">
                    <h3>Detalhes do Aluguel de Carro</h3>
                    <button class="modal-close">&times;</button>
                </div>
                
                <div class="modal-body">
                    <div class="car-details">
                        <div class="car-image">
                            <img src="${offerData.image}" alt="${offerData.company} - ${offerData.carType}">
                        </div>
                        
                        <div class="car-info">
                            <h4>${offerData.company}</h4>
                            <div class="car-type">
                                <i class="fas fa-car"></i> ${offerData.carType}
                            </div>
                            <div class="car-location">
                                <i class="fas fa-map-marker-alt"></i> ${offerData.location}
                            </div>
                        </div>
                        
                        <div class="dates-details">
                            <div class="dates">
                                <i class="far fa-calendar-alt"></i> ${offerData.dates}
                            </div>
                            <div class="program">
                                <i class="fas fa-award"></i> ${getProgramName(offerData.program)}
                            </div>
                        </div>
                        
                        <div class="price-details">
                            <div class="price-section">
                                <h4>Preço em Milhas</h4>
                                <div class="price-value">${formatNumber(offerData.miles)} <span class="miles-text">milhas</span></div>
                                <div class="per-day">${offerData.perDay ? 'por dia' : 'total'}</div>
                            </div>
                            
                            <div class="price-section">
                                <h4>Preço em Dinheiro</h4>
                                <div class="price-value">${formatCurrency(offerData.cashPrice, offerData.currency)}</div>
                                <div class="per-day">${offerData.perDay ? 'por dia' : 'total'}</div>
                            </div>
                        </div>
                        
                        <div class="recommendation-details">
                            <h4>Recomendação IGo Travel</h4>
                            <div class="recommendation-badge ${offerData.recommendation === 'miles' ? 'miles' : 'cash'}">
                                <i class="fas ${offerData.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                                Melhor com ${offerData.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                            </div>
                            <div class="recommendation-explanation">
                                ${offerData.recommendation === 'miles' ? 
                                    `Usando milhas, você economiza aproximadamente ${formatCurrency(offerData.cashPrice, offerData.currency)}.` : 
                                    `Pagando em dinheiro, você economiza suas milhas para um uso mais vantajoso.`
                                }
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn-secondary" id="close-details">Fechar</button>
                    <button class="btn-secondary" id="export-pdf">
                        <i class="fas fa-file-pdf"></i> Exportar PDF
                    </button>
                    <button class="btn-secondary" id="share-whatsapp">
                        <i class="fab fa-whatsapp"></i> Compartilhar
                    </button>
                    <button class="btn-primary" id="book-now">
                        <i class="fas fa-check-circle"></i> Reservar Agora
                    </button>
                </div>
            `;
            break;
            
        case 'package':
            modalHTML = `
                <div class="modal-header">
                    <h3>Detalhes do Pacote</h3>
                    <button class="modal-close">&times;</button>
                </div>
                
                <div class="modal-body">
                    <div class="package-details">
                        <div class="package-image">
                            <img src="${offerData.image}" alt="${offerData.name}">
                        </div>
                        
                        <div class="package-info">
                            <h4>${offerData.name}</h4>
                            <div class="package-description">${offerData.description}</div>
                            <div class="package-location">
                                <i class="fas fa-map-marker-alt"></i> ${offerData.location}
                            </div>
                        </div>
                        
                        <div class="package-details-info">
                            <div class="detail-item">
                                <div class="detail-label">Hotel:</div>
                                <div class="detail-value">${offerData.hotel}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Companhia Aérea:</div>
                                <div class="detail-value">${offerData.airline}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Programa de Milhas:</div>
                                <div class="detail-value">${getProgramName(offerData.program)}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Datas:</div>
                                <div class="detail-value">${offerData.dates}</div>
                            </div>
                        </div>
                        
                        <div class="package-includes">
                            <h4>O que está incluído:</h4>
                            <div class="includes-list">
                                ${offerData.includes.map(item => `
                                    <div class="include-item">
                                        <i class="fas ${getIncludeIcon(item)}"></i> ${item}
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                        
                        <div class="price-details">
                            <div class="price-section">
                                <h4>Preço em Milhas</h4>
                                <div class="price-value">${formatNumber(offerData.miles)} <span class="miles-text">milhas</span></div>
                                <div class="taxes">+ ${formatCurrency(offerData.taxes, offerData.currency)} (taxas)</div>
                            </div>
                            
                            <div class="price-section">
                                <h4>Preço em Dinheiro</h4>
                                <div class="price-value">${formatCurrency(offerData.cashPrice, offerData.currency)}</div>
                            </div>
                        </div>
                        
                        <div class="recommendation-details">
                            <h4>Recomendação IGo Travel</h4>
                            <div class="recommendation-badge ${offerData.recommendation === 'miles' ? 'miles' : 'cash'}">
                                <i class="fas ${offerData.recommendation === 'miles' ? 'fa-award' : 'fa-dollar-sign'}"></i>
                                Melhor com ${offerData.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                            </div>
                            <div class="recommendation-explanation">
                                ${offerData.recommendation === 'miles' ? 
                                    `Usando milhas, você economiza aproximadamente ${formatCurrency(offerData.cashPrice - (offerData.taxes || 0), offerData.currency)}.` : 
                                    `Pagando em dinheiro, você economiza suas milhas para um uso mais vantajoso.`
                                }
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn-secondary" id="close-details">Fechar</button>
                    <button class="btn-secondary" id="export-pdf">
                        <i class="fas fa-file-pdf"></i> Exportar PDF
                    </button>
                    <button class="btn-secondary" id="share-whatsapp">
                        <i class="fab fa-whatsapp"></i> Compartilhar
                    </button>
                    <button class="btn-primary" id="book-now">
                        <i class="fas fa-check-circle"></i> Reservar Agora
                    </button>
                </div>
            `;
            break;
    }
    
    modalContent.innerHTML = modalHTML;
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Adiciona event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const closeDetailsButton = document.getElementById('close-details');
    closeDetailsButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const exportPdfButton = document.getElementById('export-pdf');
    exportPdfButton.addEventListener('click', () => {
        // Simula a exportação para PDF
        alert('Esta ação exportaria os detalhes para um PDF com o branding da IGo Travel.');
    });
    
    const shareWhatsappButton = document.getElementById('share-whatsapp');
    shareWhatsappButton.addEventListener('click', () => {
        // Simula o compartilhamento via WhatsApp
        alert('Esta ação compartilharia os detalhes via WhatsApp.');
    });
    
    const bookNowButton = document.getElementById('book-now');
    bookNowButton.addEventListener('click', () => {
        // Fecha o modal de detalhes
        document.body.removeChild(modalOverlay);
        
        // Abre o modal de reserva
        showBookingModal(id, type);
    });
}

// Exibe modal de reserva
function showBookingModal(id, type, routeData = null) {
    // Busca os dados da oferta com base no ID e tipo
    let offerData = null;
    
    if (id) {
        switch (type) {
            case 'flight':
                offerData = milesOffersState.milesOffers.find(offer => offer.id === id);
                break;
            case 'hotel':
                offerData = milesOffersState.hotelOffers.find(hotel => hotel.id === id);
                break;
            case 'car':
                offerData = milesOffersState.carRentalOffers.find(car => car.id === id);
                break;
            case 'package':
                offerData = milesOffersState.packageOffers.find(pkg => pkg.id === id);
                break;
        }
    } else if (routeData) {
        // Usa os dados da rota fornecidos
        offerData = routeData;
    }
    
    // Se não encontrar dados, exibe um alerta e retorna
    if (!offerData) {
        alert('Dados não encontrados para esta reserva.');
        return;
    }
    
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content booking-modal';
    
    // Título do modal com base no tipo
    let modalTitle = '';
    switch (type) {
        case 'flight':
            modalTitle = 'Reservar Voo';
            break;
        case 'hotel':
            modalTitle = 'Reservar Hotel';
            break;
        case 'car':
            modalTitle = 'Reservar Aluguel de Carro';
            break;
        case 'package':
            modalTitle = 'Reservar Pacote';
            break;
    }
    
    // Conteúdo comum do modal
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>${modalTitle}</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="booking-summary">
                <h4>Resumo da Reserva</h4>
                
                ${type === 'flight' ? `
                    <div class="summary-item">
                        <div class="summary-label">Rota:</div>
                        <div class="summary-value">${offerData.origin} → ${offerData.destination}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Companhia:</div>
                        <div class="summary-value">${offerData.airline}</div>
                    </div>
                ` : ''}
                
                ${type === 'hotel' ? `
                    <div class="summary-item">
                        <div class="summary-label">Hotel:</div>
                        <div class="summary-value">${offerData.name}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Localização:</div>
                        <div class="summary-value">${offerData.location}</div>
                    </div>
                ` : ''}
                
                ${type === 'car' ? `
                    <div class="summary-item">
                        <div class="summary-label">Locadora:</div>
                        <div class="summary-value">${offerData.company}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Tipo de Carro:</div>
                        <div class="summary-value">${offerData.carType}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Localização:</div>
                        <div class="summary-value">${offerData.location}</div>
                    </div>
                ` : ''}
                
                ${type === 'package' ? `
                    <div class="summary-item">
                        <div class="summary-label">Pacote:</div>
                        <div class="summary-value">${offerData.name}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Destino:</div>
                        <div class="summary-value">${offerData.location}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Hotel:</div>
                        <div class="summary-value">${offerData.hotel}</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Companhia:</div>
                        <div class="summary-value">${offerData.airline}</div>
                    </div>
                ` : ''}
                
                <div class="summary-item">
                    <div class="summary-label">Datas:</div>
                    <div class="summary-value">${offerData.dates}</div>
                </div>
                
                <div class="summary-item">
                    <div class="summary-label">Programa:</div>
                    <div class="summary-value">${getProgramName(offerData.program)}</div>
                </div>
            </div>
            
            <div class="payment-options">
                <h4>Opções de Pagamento</h4>
                
                <div class="payment-tabs">
                    <div class="payment-tab active" data-payment="miles">
                        <i class="fas fa-award"></i> Milhas
                    </div>
                    <div class="payment-tab" data-payment="cash">
                        <i class="fas fa-dollar-sign"></i> Dinheiro
                    </div>
                </div>
                
                <div class="payment-content miles-payment active">
                    <div class="price-summary">
                        <div class="price-item">
                            <div class="price-label">Milhas:</div>
                            <div class="price-value">${formatNumber(offerData.miles)} milhas</div>
                        </div>
                        ${offerData.taxes ? `
                            <div class="price-item">
                                <div class="price-label">Taxas:</div>
                                <div class="price-value">${formatCurrency(offerData.taxes, offerData.currency)}</div>
                            </div>
                        ` : ''}
                    </div>
                    
                    <div class="program-login">
                        <h5>Acesse sua conta ${getProgramName(offerData.program)}</h5>
                        <div class="form-group">
                            <label for="program-email">E-mail ou CPF</label>
                            <input type="text" id="program-email" class="form-control" placeholder="Seu e-mail ou CPF">
                        </div>
                        <div class="form-group">
                            <label for="program-password">Senha</label>
                            <input type="password" id="program-password" class="form-control" placeholder="Sua senha">
                        </div>
                        <div class="form-group">
                            <button class="btn-primary" id="login-program-btn">
                                <i class="fas fa-sign-in-alt"></i> Acessar Conta
                            </button>
                        </div>
                        <div class="alternative-option">
                            <p>Prefere não fazer login? <a href="#" id="contact-consultant">Fale com um consultor</a></p>
                        </div>
                    </div>
                </div>
                
                <div class="payment-content cash-payment">
                    <div class="price-summary">
                        <div class="price-item">
                            <div class="price-label">Valor Total:</div>
                            <div class="price-value">${formatCurrency(offerData.cashPrice, offerData.currency)}</div>
                        </div>
                    </div>
                    
                    <div class="payment-methods">
                        <h5>Formas de Pagamento</h5>
                        
                        <div class="payment-method-tabs">
                            <div class="method-tab active" data-method="credit-card">
                                <i class="fas fa-credit-card"></i> Cartão de Crédito
                            </div>
                            <div class="method-tab" data-method="affirm">
                                <i class="fas fa-percentage"></i> Affirm (Canadá/EUA)
                            </div>
                            <div class="method-tab" data-method="pix">
                                <i class="fas fa-qrcode"></i> Pix (5% off)
                            </div>
                        </div>
                        
                        <div class="method-content credit-card-method active">
                            <div class="form-group">
                                <label for="card-number">Número do Cartão</label>
                                <input type="text" id="card-number" class="form-control" placeholder="0000 0000 0000 0000">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="card-expiry">Validade</label>
                                    <input type="text" id="card-expiry" class="form-control" placeholder="MM/AA">
                                </div>
                                <div class="form-group">
                                    <label for="card-cvv">CVV</label>
                                    <input type="text" id="card-cvv" class="form-control" placeholder="123">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="card-name">Nome no Cartão</label>
                                <input type="text" id="card-name" class="form-control" placeholder="Nome como aparece no cartão">
                            </div>
                            <div class="form-group">
                                <label for="card-installments">Parcelas</label>
                                <select id="card-installments" class="form-control">
                                    <option value="1">À vista</option>
                                    <option value="3">3x sem juros</option>
                                    <option value="6">6x sem juros</option>
                                    <option value="12">12x sem juros</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="method-content affirm-method">
                            <div class="affirm-info">
                                <p>Financie sua viagem com Affirm (disponível para clientes no Canadá e EUA).</p>
                                <p>Parcele em até 12x com aprovação instantânea.</p>
                                <button class="btn-primary" id="affirm-checkout-btn">
                                    <i class="fas fa-percentage"></i> Checkout com Affirm
                                </button>
                            </div>
                        </div>
                        
                        <div class="method-content pix-method">
                            <div class="pix-info">
                                <p>Pague com Pix e ganhe 5% de desconto!</p>
                                <p>Valor com desconto: ${formatCurrency(offerData.cashPrice * 0.95, offerData.currency)}</p>
                                <div class="pix-qrcode">
                                    <div class="qrcode-placeholder">
                                        <i class="fas fa-qrcode"></i>
                                    </div>
                                    <p>QR Code será gerado após confirmação</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="contact-info">
                <h4>Informações de Contato</h4>
                <div class="form-group">
                    <label for="contact-name">Nome Completo</label>
                    <input type="text" id="contact-name" class="form-control" placeholder="Seu nome completo">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="contact-email">E-mail</label>
                        <input type="email" id="contact-email" class="form-control" placeholder="Seu e-mail">
                    </div>
                    <div class="form-group">
                        <label for="contact-phone">Telefone</label>
                        <input type="tel" id="contact-phone" class="form-control" placeholder="Seu telefone">
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-secondary" id="cancel-booking">Cancelar</button>
            <button class="btn-secondary" id="contact-whatsapp">
                <i class="fab fa-whatsapp"></i> Reservar via WhatsApp
            </button>
            <button class="btn-primary" id="confirm-booking">
                <i class="fas fa-check-circle"></i> Confirmar Reserva
            </button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Adiciona event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const cancelButton = document.getElementById('cancel-booking');
    cancelButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const contactWhatsappButton = document.getElementById('contact-whatsapp');
    contactWhatsappButton.addEventListener('click', () => {
        // Simula o contato via WhatsApp
        alert('Esta ação abriria o WhatsApp com uma mensagem pré-preenchida para o consultor da IGo Travel.');
        document.body.removeChild(modalOverlay);
    });
    
    const confirmBookingButton = document.getElementById('confirm-booking');
    confirmBookingButton.addEventListener('click', () => {
        // Simula a confirmação da reserva
        alert('Reserva confirmada! Um e-mail de confirmação será enviado em breve.');
        document.body.removeChild(modalOverlay);
    });
    
    const contactConsultantLink = document.getElementById('contact-consultant');
    contactConsultantLink.addEventListener('click', (e) => {
        e.preventDefault();
        // Simula o contato com um consultor
        alert('Um consultor da IGo Travel entrará em contato em breve para ajudar com sua reserva.');
    });
    
    // Event listeners para as abas de pagamento
    const paymentTabs = document.querySelectorAll('.payment-tab');
    const paymentContents = document.querySelectorAll('.payment-content');
    
    paymentTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove a classe active de todas as abas e conteúdos
            paymentTabs.forEach(t => t.classList.remove('active'));
            paymentContents.forEach(c => c.classList.remove('active'));
            
            // Adiciona a classe active à aba clicada e ao conteúdo correspondente
            tab.classList.add('active');
            const paymentType = tab.dataset.payment;
            document.querySelector(`.${paymentType}-payment`).classList.add('active');
        });
    });
    
    // Event listeners para as abas de métodos de pagamento
    const methodTabs = document.querySelectorAll('.method-tab');
    const methodContents = document.querySelectorAll('.method-content');
    
    methodTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove a classe active de todas as abas e conteúdos
            methodTabs.forEach(t => t.classList.remove('active'));
            methodContents.forEach(c => c.classList.remove('active'));
            
            // Adiciona a classe active à aba clicada e ao conteúdo correspondente
            tab.classList.add('active');
            const methodType = tab.dataset.method;
            document.querySelector(`.${methodType}-method`).classList.add('active');
        });
    });
    
    // Event listener para o botão de login no programa
    const loginProgramButton = document.getElementById('login-program-btn');
    loginProgramButton.addEventListener('click', () => {
        // Simula o login no programa de milhas
        alert('Esta ação faria login no programa de milhas e verificaria o saldo disponível.');
    });
    
    // Event listener para o botão de checkout com Affirm
    const affirmCheckoutButton = document.getElementById('affirm-checkout-btn');
    if (affirmCheckoutButton) {
        affirmCheckoutButton.addEventListener('click', () => {
            // Simula o checkout com Affirm
            alert('Esta ação redirecionaria para o checkout do Affirm.');
        });
    }
}

// Exibe modal de compartilhamento
function showShareModal(id, type) {
    // Busca os dados da oferta com base no ID e tipo
    let offerData = null;
    
    switch (type) {
        case 'flight':
            offerData = milesOffersState.milesOffers.find(offer => offer.id === id);
            break;
        case 'hotel':
            offerData = milesOffersState.hotelOffers.find(hotel => hotel.id === id);
            break;
        case 'car':
            offerData = milesOffersState.carRentalOffers.find(car => car.id === id);
            break;
        case 'package':
            offerData = milesOffersState.packageOffers.find(pkg => pkg.id === id);
            break;
    }
    
    // Se não encontrar dados, exibe um alerta e retorna
    if (!offerData) {
        alert('Dados não encontrados para compartilhamento.');
        return;
    }
    
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content share-modal';
    
    // Título do modal com base no tipo
    let modalTitle = '';
    let offerTitle = '';
    
    switch (type) {
        case 'flight':
            modalTitle = 'Compartilhar Voo';
            offerTitle = `Voo ${offerData.origin} → ${offerData.destination}`;
            break;
        case 'hotel':
            modalTitle = 'Compartilhar Hotel';
            offerTitle = offerData.name;
            break;
        case 'car':
            modalTitle = 'Compartilhar Aluguel de Carro';
            offerTitle = `${offerData.company} - ${offerData.carType}`;
            break;
        case 'package':
            modalTitle = 'Compartilhar Pacote';
            offerTitle = offerData.name;
            break;
    }
    
    // Conteúdo do modal
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>${modalTitle}</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="share-preview">
                <h4>Prévia</h4>
                <div class="preview-card">
                    <div class="preview-header">
                        <img src="https://via.placeholder.com/100x30?text=IGo+Travel" alt="IGo Travel" class="preview-logo">
                    </div>
                    
                    <div class="preview-content">
                        <h5>${offerTitle}</h5>
                        
                        ${type === 'flight' ? `
                            <div class="preview-detail">
                                <i class="fas fa-plane"></i> ${offerData.airline}
                            </div>
                        ` : ''}
                        
                        ${type === 'hotel' ? `
                            <div class="preview-detail">
                                <i class="fas fa-map-marker-alt"></i> ${offerData.location}
                            </div>
                        ` : ''}
                        
                        ${type === 'car' ? `
                            <div class="preview-detail">
                                <i class="fas fa-map-marker-alt"></i> ${offerData.location}
                            </div>
                        ` : ''}
                        
                        ${type === 'package' ? `
                            <div class="preview-detail">
                                <i class="fas fa-map-marker-alt"></i> ${offerData.location}
                            </div>
                            <div class="preview-detail">
                                <i class="fas fa-hotel"></i> ${offerData.hotel}
                            </div>
                        ` : ''}
                        
                        <div class="preview-detail">
                            <i class="far fa-calendar-alt"></i> ${offerData.dates}
                        </div>
                        
                        <div class="preview-prices">
                            <div class="preview-price miles">
                                <div class="price-label">Milhas:</div>
                                <div class="price-value">${formatNumber(offerData.miles)}</div>
                            </div>
                            
                            <div class="preview-price cash">
                                <div class="price-label">Dinheiro:</div>
                                <div class="price-value">${formatCurrency(offerData.cashPrice, offerData.currency)}</div>
                            </div>
                        </div>
                        
                        <div class="preview-recommendation">
                            Melhor com ${offerData.recommendation === 'miles' ? 'milhas' : 'dinheiro'}
                        </div>
                    </div>
                    
                    <div class="preview-footer">
                        <div class="preview-contact">
                            Reservas: (11) 99999-9999
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="share-options">
                <h4>Opções de Compartilhamento</h4>
                
                <div class="share-format-tabs">
                    <div class="format-tab active" data-format="image">
                        <i class="fas fa-image"></i> Imagem
                    </div>
                    <div class="format-tab" data-format="pdf">
                        <i class="fas fa-file-pdf"></i> PDF
                    </div>
                    <div class="format-tab" data-format="text">
                        <i class="fas fa-align-left"></i> Texto
                    </div>
                </div>
                
                <div class="format-content image-format active">
                    <div class="format-options">
                        <div class="option-group">
                            <label>Formato:</label>
                            <div class="option-buttons">
                                <button class="option-button active" data-option="story">Story</button>
                                <button class="option-button" data-option="post">Post</button>
                            </div>
                        </div>
                        
                        <div class="option-group">
                            <label>Incluir Logo:</label>
                            <div class="option-buttons">
                                <button class="option-button active" data-option="yes">Sim</button>
                                <button class="option-button" data-option="no">Não</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="format-content pdf-format">
                    <div class="format-options">
                        <div class="option-group">
                            <label>Incluir Detalhes:</label>
                            <div class="option-buttons">
                                <button class="option-button active" data-option="basic">Básico</button>
                                <button class="option-button" data-option="complete">Completo</button>
                            </div>
                        </div>
                        
                        <div class="option-group">
                            <label>Incluir Contato:</label>
                            <div class="option-buttons">
                                <button class="option-button active" data-option="yes">Sim</button>
                                <button class="option-button" data-option="no">Não</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="format-content text-format">
                    <div class="text-preview">
                        <textarea class="form-control" rows="6" readonly>🔥 OFERTA IMPERDÍVEL! 🔥

${offerTitle}
✈️ ${type === 'flight' ? offerData.airline : (type === 'package' ? offerData.airline : '')}
📅 ${offerData.dates}
💰 A partir de ${formatCurrency(offerData.cashPrice, offerData.currency)}
🏆 Ou ${formatNumber(offerData.miles)} milhas

👉 Reservas: (11) 99999-9999
#IGOTravel #Viagem #Milhas</textarea>
                    </div>
                    <div class="text-actions">
                        <button class="btn-secondary btn-sm" id="copy-text-btn">
                            <i class="fas fa-copy"></i> Copiar Texto
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-secondary" id="cancel-share">Cancelar</button>
            <button class="btn-secondary" id="download-share">
                <i class="fas fa-download"></i> Download
            </button>
            <button class="btn-primary" id="share-whatsapp">
                <i class="fab fa-whatsapp"></i> Compartilhar no WhatsApp
            </button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Adiciona event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const cancelButton = document.getElementById('cancel-share');
    cancelButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const downloadButton = document.getElementById('download-share');
    downloadButton.addEventListener('click', () => {
        // Simula o download
        const activeFormat = document.querySelector('.format-tab.active').dataset.format;
        alert(`Esta ação faria o download da oferta no formato ${activeFormat}.`);
    });
    
    const shareWhatsappButton = document.getElementById('share-whatsapp');
    shareWhatsappButton.addEventListener('click', () => {
        // Simula o compartilhamento via WhatsApp
        alert('Esta ação compartilharia a oferta via WhatsApp.');
        document.body.removeChild(modalOverlay);
    });
    
    // Event listeners para as abas de formato
    const formatTabs = document.querySelectorAll('.format-tab');
    const formatContents = document.querySelectorAll('.format-content');
    
    formatTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove a classe active de todas as abas e conteúdos
            formatTabs.forEach(t => t.classList.remove('active'));
            formatContents.forEach(c => c.classList.remove('active'));
            
            // Adiciona a classe active à aba clicada e ao conteúdo correspondente
            tab.classList.add('active');
            const formatType = tab.dataset.format;
            document.querySelector(`.${formatType}-format`).classList.add('active');
        });
    });
    
    // Event listeners para os botões de opção
    const optionButtons = document.querySelectorAll('.option-button');
    
    optionButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove a classe active de todos os botões no mesmo grupo
            const group = button.closest('.option-group');
            group.querySelectorAll('.option-button').forEach(b => b.classList.remove('active'));
            
            // Adiciona a classe active ao botão clicado
            button.classList.add('active');
        });
    });
    
    // Event listener para o botão de copiar texto
    const copyTextButton = document.getElementById('copy-text-btn');
    if (copyTextButton) {
        copyTextButton.addEventListener('click', () => {
            const textarea = document.querySelector('.text-preview textarea');
            textarea.select();
            document.execCommand('copy');
            
            // Altera o texto do botão temporariamente
            const originalText = copyTextButton.innerHTML;
            copyTextButton.innerHTML = '<i class="fas fa-check"></i> Copiado!';
            
            setTimeout(() => {
                copyTextButton.innerHTML = originalText;
            }, 2000);
        });
    }
}

// Funções auxiliares

// Obtém o nome do programa de milhas a partir do ID
function getProgramName(programId) {
    const program = milesOffersState.supportedPrograms.find(p => p.id === programId);
    return program ? program.name : programId;
}

// Obtém o ícone para um item incluído em um pacote
function getIncludeIcon(item) {
    switch (item.toLowerCase()) {
        case 'voo':
            return 'fa-plane';
        case 'hotel':
            return 'fa-hotel';
        case 'transfer':
            return 'fa-shuttle-van';
        case 'carro':
            return 'fa-car';
        case 'alimentação':
            return 'fa-utensils';
        default:
            return 'fa-check-circle';
    }
}

// Formata um número com separadores de milhar
function formatNumber(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

// Formata um valor monetário
function formatCurrency(value, currency) {
    if (!value) return '';
    
    let symbol = '';
    
    switch (currency) {
        case 'BRL':
            symbol = 'R$';
            break;
        case 'CAD':
            symbol = 'CAD $';
            break;
        case 'USD':
            symbol = 'US $';
            break;
        default:
            symbol = '$';
    }
    
    return `${symbol} ${value.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ".")}`;
}

// Inicializa o sistema quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initMilesOffersSystem();
});
