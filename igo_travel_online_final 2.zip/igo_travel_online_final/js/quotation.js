/**
 * Sistema de Cotação Inteligente com Condições Especiais da IGO Travel
 * Hub IGO Travel
 */

// Estado do sistema de cotação
let quotationState = {
    destination: '',
    dates: {
        departure: '',
        return: ''
    },
    travelers: {
        adults: 1,
        children: 0,
        infants: 0
    },
    preferences: {
        accommodation: 'comfort',
        activities: [],
        budget: 'medium'
    },
    currentStep: 0,
    totalSteps: 4,
    quotationOptions: [],
    selectedOption: null,
    specialConditionsEnabled: true
};

// Configuração dos passos da cotação
const quotationSteps = [
    {
        id: 'destination',
        title: 'Destino',
        question: 'Para onde você gostaria de viajar?',
        description: 'Escolha seu destino dos sonhos ou deixe que eu sugira opções baseadas nos seus interesses.'
    },
    {
        id: 'dates',
        title: 'Datas',
        question: 'Quando você planeja viajar?',
        description: 'Selecione as datas ou período aproximado da sua viagem.'
    },
    {
        id: 'travelers',
        title: 'Viajantes',
        question: 'Quem vai viajar com você?',
        description: 'Informe quantas pessoas vão participar da viagem.'
    },
    {
        id: 'preferences',
        title: 'Preferências',
        question: 'Quais são suas preferências para esta viagem?',
        description: 'Selecione suas preferências para que possamos personalizar sua cotação.'
    }
];

// Inicializa o sistema de cotação
function initQuotation() {
    // Verifica se há parâmetros na URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('destination')) {
        quotationState.destination = urlParams.get('destination');
        quotationState.currentStep = 1; // Pula o primeiro passo
    }
    
    if (urlParams.has('special')) {
        quotationState.specialConditionsEnabled = urlParams.get('special') === 'true';
    }
    
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    renderQuotationUI(quotationContainer);
    attachEventListeners();
}

// Renderiza a interface do sistema de cotação
function renderQuotationUI(container) {
    // Se já temos opções de cotação, mostramos os resultados
    if (quotationState.quotationOptions.length > 0) {
        renderQuotationResults(container);
        return;
    }
    
    // Cabeçalho da cotação
    const header = document.createElement('div');
    header.className = 'quotation-header';
    header.innerHTML = `
        <div class="quotation-title">
            <h2><i class="fas fa-calculator"></i> Cotação Inteligente</h2>
            <p>Encontre as melhores opções para sua viagem</p>
        </div>
        <div class="quotation-progress">
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${(quotationState.currentStep / quotationState.totalSteps) * 100}%"></div>
            </div>
            <div class="progress-steps">
                <span>Passo ${quotationState.currentStep + 1} de ${quotationState.totalSteps}</span>
            </div>
        </div>
    `;
    container.appendChild(header);
    
    // Conteúdo do passo atual
    const currentStep = quotationSteps[quotationState.currentStep];
    const stepContent = document.createElement('div');
    stepContent.className = 'quotation-step';
    stepContent.innerHTML = `
        <div class="step-question">
            <h3>${currentStep.question}</h3>
            <p>${currentStep.description}</p>
        </div>
        <div class="step-input" id="step-input-${currentStep.id}">
            ${renderStepInput(currentStep)}
        </div>
    `;
    container.appendChild(stepContent);
    
    // Botões de navegação
    const navigation = document.createElement('div');
    navigation.className = 'quotation-navigation';
    navigation.innerHTML = `
        <button class="btn-secondary" id="quotation-back" ${quotationState.currentStep === 0 ? 'disabled' : ''}>
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
        <button class="btn-primary" id="quotation-next">
            ${quotationState.currentStep === quotationState.totalSteps - 1 ? 'Gerar Cotação' : 'Continuar'} <i class="fas fa-arrow-right"></i>
        </button>
    `;
    container.appendChild(navigation);
    
    // Assistente virtual (chat)
    const assistant = document.createElement('div');
    assistant.className = 'quotation-assistant';
    assistant.innerHTML = `
        <div class="assistant-avatar">
            <i class="fas fa-user-tie"></i>
        </div>
        <div class="assistant-message">
            <p>${getAssistantMessage(currentStep)}</p>
            <div class="assistant-typing">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
            </div>
        </div>
    `;
    container.appendChild(assistant);
}

// Renderiza o input específico para cada passo
function renderStepInput(step) {
    switch (step.id) {
        case 'destination':
            return `
                <div class="destination-search">
                    <input type="text" id="destination-input" placeholder="Digite o destino desejado" class="form-control" value="${quotationState.destination}">
                    <div class="destination-suggestions">
                        <div class="suggestion-item" data-value="Toronto">Toronto</div>
                        <div class="suggestion-item" data-value="Nova York">Nova York</div>
                        <div class="suggestion-item" data-value="Paris">Paris</div>
                        <div class="suggestion-item" data-value="Tóquio">Tóquio</div>
                        <div class="suggestion-item" data-value="Cancún">Cancún</div>
                        <div class="suggestion-item" data-value="Rio de Janeiro">Rio de Janeiro</div>
                    </div>
                </div>
            `;
        
        case 'dates':
            return `
                <div class="date-selector">
                    <div class="date-range">
                        <div class="date-field">
                            <label>Ida</label>
                            <input type="date" id="departure-date" class="form-control" value="${quotationState.dates.departure}">
                        </div>
                        <div class="date-field">
                            <label>Volta</label>
                            <input type="date" id="return-date" class="form-control" value="${quotationState.dates.return}">
                        </div>
                    </div>
                    <div class="date-suggestions">
                        <div class="suggestion-item" data-value="Próximo mês">Próximo mês</div>
                        <div class="suggestion-item" data-value="Próximos 3 meses">Próximos 3 meses</div>
                        <div class="suggestion-item" data-value="Férias de verão">Férias de verão</div>
                        <div class="suggestion-item" data-value="Férias de inverno">Férias de inverno</div>
                    </div>
                </div>
            `;
        
        case 'travelers':
            return `
                <div class="traveler-counter">
                    <div class="traveler-type">
                        <label>Adultos</label>
                        <div class="counter">
                            <button class="counter-btn minus" data-type="adults">-</button>
                            <span class="counter-value" id="adults-count">${quotationState.travelers.adults}</span>
                            <button class="counter-btn plus" data-type="adults">+</button>
                        </div>
                    </div>
                    <div class="traveler-type">
                        <label>Crianças (2-11 anos)</label>
                        <div class="counter">
                            <button class="counter-btn minus" data-type="children">-</button>
                            <span class="counter-value" id="children-count">${quotationState.travelers.children}</span>
                            <button class="counter-btn plus" data-type="children">+</button>
                        </div>
                    </div>
                    <div class="traveler-type">
                        <label>Bebês (0-2 anos)</label>
                        <div class="counter">
                            <button class="counter-btn minus" data-type="infants">-</button>
                            <span class="counter-value" id="infants-count">${quotationState.travelers.infants}</span>
                            <button class="counter-btn plus" data-type="infants">+</button>
                        </div>
                    </div>
                </div>
            `;
        
        case 'preferences':
            return `
                <div class="preferences-selector">
                    <div class="preference-section">
                        <h4>Tipo de Acomodação</h4>
                        <div class="accommodation-options">
                            <div class="accommodation-option ${quotationState.preferences.accommodation === 'economic' ? 'selected' : ''}" data-value="economic">
                                <div class="option-icon"><i class="fas fa-bed"></i></div>
                                <div class="option-label">Econômico</div>
                                <div class="option-description">Hotéis 3 estrelas com boa localização e custo-benefício</div>
                            </div>
                            <div class="accommodation-option ${quotationState.preferences.accommodation === 'comfort' ? 'selected' : ''}" data-value="comfort">
                                <div class="option-icon"><i class="fas fa-hotel"></i></div>
                                <div class="option-label">Conforto</div>
                                <div class="option-description">Hotéis 4 estrelas com excelente localização e serviços</div>
                            </div>
                            <div class="accommodation-option ${quotationState.preferences.accommodation === 'premium' ? 'selected' : ''}" data-value="premium">
                                <div class="option-icon"><i class="fas fa-concierge-bell"></i></div>
                                <div class="option-label">Premium</div>
                                <div class="option-description">Hotéis 5 estrelas com serviços exclusivos e luxuosos</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="preference-section">
                        <h4>Atividades de Interesse</h4>
                        <div class="activities-options">
                            <div class="activity-option" data-value="culture">
                                <div class="option-icon"><i class="fas fa-landmark"></i></div>
                                <div class="option-label">Cultura e História</div>
                            </div>
                            <div class="activity-option" data-value="nature">
                                <div class="option-icon"><i class="fas fa-mountain"></i></div>
                                <div class="option-label">Natureza e Aventura</div>
                            </div>
                            <div class="activity-option" data-value="gastronomy">
                                <div class="option-icon"><i class="fas fa-utensils"></i></div>
                                <div class="option-label">Gastronomia</div>
                            </div>
                            <div class="activity-option" data-value="shopping">
                                <div class="option-icon"><i class="fas fa-shopping-bag"></i></div>
                                <div class="option-label">Compras</div>
                            </div>
                            <div class="activity-option" data-value="nightlife">
                                <div class="option-icon"><i class="fas fa-moon"></i></div>
                                <div class="option-label">Vida Noturna</div>
                            </div>
                            <div class="activity-option" data-value="relaxation">
                                <div class="option-icon"><i class="fas fa-spa"></i></div>
                                <div class="option-label">Relaxamento</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="preference-section">
                        <h4>Orçamento Aproximado</h4>
                        <div class="budget-slider-container">
                            <input type="range" min="1" max="5" value="3" class="budget-slider" id="budget-slider">
                            <div class="budget-labels">
                                <span>Econômico</span>
                                <span>Moderado</span>
                                <span>Premium</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="preference-section special-conditions-section">
                        <div class="special-conditions-toggle">
                            <label class="toggle-label">
                                <input type="checkbox" id="special-conditions-toggle" ${quotationState.specialConditionsEnabled ? 'checked' : ''}>
                                <span class="toggle-switch"></span>
                                <span class="toggle-text">Incluir Condições Especiais da IGO Travel</span>
                            </label>
                        </div>
                        <div class="special-conditions-info">
                            <p>As Condições Especiais da IGO Travel oferecem benefícios exclusivos como upgrades, transfers privativos, experiências VIP e muito mais.</p>
                        </div>
                    </div>
                </div>
            `;
        
        default:
            return `<input type="text" class="form-control" placeholder="Digite sua resposta">`;
    }
}

// Obtém mensagem personalizada do assistente para cada passo
function getAssistantMessage(step) {
    switch (step.id) {
        case 'destination':
            return "Olá! Sou seu assistente de cotações. Para começar, me conte para onde você gostaria de viajar. Posso sugerir destinos populares ou você pode digitar um local específico.";
        
        case 'dates':
            return `Ótima escolha! ${quotationState.destination} é um destino incrível. Agora, vamos definir quando você planeja viajar. Selecione as datas ou escolha um período aproximado.`;
        
        case 'travelers':
            return "Perfeito! Agora me conte quem vai participar desta viagem. Quantos adultos, crianças e bebês vão viajar?";
        
        case 'preferences':
            return "Estamos quase lá! Por último, me conte suas preferências para esta viagem. Isso me ajudará a encontrar as melhores opções que se encaixem no seu perfil.";
        
        default:
            return "Como posso ajudar com sua cotação hoje?";
    }
}

// Anexa event listeners aos elementos interativos
function attachEventListeners() {
    // Botão de próximo passo
    const nextButton = document.getElementById('quotation-next');
    if (nextButton) {
        nextButton.addEventListener('click', () => {
            if (validateCurrentStep()) {
                saveCurrentStepData();
                
                if (quotationState.currentStep === quotationState.totalSteps - 1) {
                    // Último passo - gerar cotação
                    generateQuotation();
                } else {
                    // Avançar para o próximo passo
                    quotationState.currentStep++;
                    updateQuotationUI();
                }
            }
        });
    }
    
    // Botão de passo anterior
    const backButton = document.getElementById('quotation-back');
    if (backButton) {
        backButton.addEventListener('click', () => {
            if (quotationState.currentStep > 0) {
                quotationState.currentStep--;
                updateQuotationUI();
            }
        });
    }
    
    // Event listeners específicos para cada tipo de input
    attachStepSpecificListeners();
}

// Anexa event listeners específicos para o passo atual
function attachStepSpecificListeners() {
    const currentStep = quotationSteps[quotationState.currentStep];
    
    switch (currentStep.id) {
        case 'destination':
            // Sugestões de destino
            const suggestionItems = document.querySelectorAll('.suggestion-item');
            suggestionItems.forEach(item => {
                item.addEventListener('click', () => {
                    document.getElementById('destination-input').value = item.dataset.value;
                    suggestionItems.forEach(si => si.classList.remove('selected'));
                    item.classList.add('selected');
                });
            });
            break;
        
        case 'travelers':
            // Botões de incremento/decremento
            const counterButtons = document.querySelectorAll('.counter-btn');
            counterButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const type = button.dataset.type;
                    const isPlus = button.classList.contains('plus');
                    const countElement = document.getElementById(`${type}-count`);
                    let count = parseInt(countElement.textContent);
                    
                    if (isPlus) {
                        count++;
                    } else if (count > 0) {
                        count--;
                    }
                    
                    countElement.textContent = count;
                });
            });
            break;
        
        case 'preferences':
            // Seleção de acomodação
            const accommodationOptions = document.querySelectorAll('.accommodation-option');
            accommodationOptions.forEach(option => {
                option.addEventListener('click', () => {
                    accommodationOptions.forEach(ao => ao.classList.remove('selected'));
                    option.classList.add('selected');
                });
            });
            
            // Seleção de atividades
            const activityOptions = document.querySelectorAll('.activity-option');
            activityOptions.forEach(option => {
                option.addEventListener('click', () => {
                    option.classList.toggle('selected');
                });
            });
            
            // Toggle de condições especiais
            const specialConditionsToggle = document.getElementById('special-conditions-toggle');
            if (specialConditionsToggle) {
                specialConditionsToggle.addEventListener('change', () => {
                    quotationState.specialConditionsEnabled = specialConditionsToggle.checked;
                });
            }
            break;
    }
}

// Valida os dados do passo atual
function validateCurrentStep() {
    const currentStep = quotationSteps[quotationState.currentStep];
    
    switch (currentStep.id) {
        case 'destination':
            const destination = document.getElementById('destination-input').value;
            return destination.trim() !== '';
        
        case 'dates':
            const departureDate = document.getElementById('departure-date').value;
            const returnDate = document.getElementById('return-date').value;
            return departureDate !== '' && returnDate !== '';
        
        case 'travelers':
            const adultsCount = parseInt(document.getElementById('adults-count').textContent);
            return adultsCount > 0;
        
        case 'preferences':
            return true; // Todas as preferências são opcionais
        
        default:
            return true;
    }
}

// Salva os dados do passo atual
function saveCurrentStepData() {
    const currentStep = quotationSteps[quotationState.currentStep];
    
    switch (currentStep.id) {
        case 'destination':
            quotationState.destination = document.getElementById('destination-input').value;
            break;
        
        case 'dates':
            quotationState.dates.departure = document.getElementById('departure-date').value;
            quotationState.dates.return = document.getElementById('return-date').value;
            break;
        
        case 'travelers':
            quotationState.travelers.adults = parseInt(document.getElementById('adults-count').textContent);
            quotationState.travelers.children = parseInt(document.getElementById('children-count').textContent);
            quotationState.travelers.infants = parseInt(document.getElementById('infants-count').textContent);
            break;
        
        case 'preferences':
            // Acomodação
            const selectedAccommodation = document.querySelector('.accommodation-option.selected');
            if (selectedAccommodation) {
                quotationState.preferences.accommodation = selectedAccommodation.dataset.value;
            }
            
            // Atividades
            const selectedActivities = document.querySelectorAll('.activity-option.selected');
            quotationState.preferences.activities = Array.from(selectedActivities).map(el => el.dataset.value);
            
            // Orçamento
            const budgetSlider = document.getElementById('budget-slider');
            if (budgetSlider) {
                const budgetValue = parseInt(budgetSlider.value);
                quotationState.preferences.budget = budgetValue <= 2 ? 'low' : budgetValue >= 4 ? 'high' : 'medium';
            }
            
            // Condições especiais
            const specialConditionsToggle = document.getElementById('special-conditions-toggle');
            if (specialConditionsToggle) {
                quotationState.specialConditionsEnabled = specialConditionsToggle.checked;
            }
            break;
    }
}

// Atualiza a interface do sistema de cotação
function updateQuotationUI() {
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    // Limpa o conteúdo atual
    quotationContainer.innerHTML = '';
    
    // Renderiza a nova interface
    renderQuotationUI(quotationContainer);
    
    // Anexa novos event listeners
    attachEventListeners();
}

// Gera cotação baseada nas seleções do usuário
function generateQuotation() {
    // Simula chamada à API de IA
    simulateAIProcessing().then(() => {
        // Gera opções de cotação baseadas nas seleções do usuário
        const quotationOptions = generateQuotationOptions();
        quotationState.quotationOptions = quotationOptions;
        
        // Exibe as opções de cotação
        updateQuotationUI();
    });
}

// Simula processamento da IA
function simulateAIProcessing() {
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return Promise.resolve();
    
    // Exibe indicador de carregamento
    quotationContainer.innerHTML = `
        <div class="ai-processing">
            <div class="processing-animation">
                <div class="processing-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="processing-dots">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
            </div>
            <h3>Processando sua cotação</h3>
            <p>Estou analisando milhares de opções para encontrar as melhores condições para sua viagem a ${quotationState.destination}...</p>
        </div>
    `;
    
    // Simula tempo de processamento
    return new Promise(resolve => {
        setTimeout(resolve, 3000);
    });
}

// Gera opções de cotação baseadas nas seleções do usuário
function generateQuotationOptions() {
    const destination = quotationState.destination;
    const accommodation = quotationState.preferences.accommodation;
    const budget = quotationState.preferences.budget;
    
    // Preços base por tipo de acomodação e orçamento
    const basePrices = {
        economic: {
            low: 3500,
            medium: 4500,
            high: 5500
        },
        comfort: {
            low: 5500,
            medium: 7000,
            high: 8500
        },
        premium: {
            low: 8500,
            medium: 10500,
            high: 13000
        }
    };
    
    // Preço base para o destino e acomodação selecionados
    const basePrice = basePrices[accommodation][budget];
    
    // Multiplicador por destino (simulado)
    const destinationMultipliers = {
        'Toronto': 1.0,
        'Nova York': 1.2,
        'Paris': 1.3,
        'Tóquio': 1.5,
        'Cancún': 0.9,
        'Rio de Janeiro': 0.8
    };
    
    const multiplier = destinationMultipliers[destination] || 1.0;
    
    // Preço final por pessoa
    const pricePerPerson = basePrice * multiplier;
    
    // Preço total para todos os viajantes
    const totalTravelers = quotationState.travelers.adults + quotationState.travelers.children * 0.7;
    const totalPrice = pricePerPerson * totalTravelers;
    
    // Opções de cotação
    const options = [
        {
            id: 'standard',
            title: `Pacote ${accommodation === 'premium' ? 'Premium' : accommodation === 'comfort' ? 'Conforto' : 'Econômico'} para ${destination}`,
            description: `Experimente o melhor de ${destination} com este pacote que inclui passagens aéreas, hospedagem e atividades selecionadas.`,
            price: totalPrice,
            pricePerPerson: pricePerPerson,
            currency: 'BRL',
            paymentType: 'standard',
            highlights: [
                'Passagens aéreas de ida e volta',
                `Hospedagem em hotel ${accommodation === 'premium' ? '5 estrelas' : accommodation === 'comfort' ? '4 estrelas' : '3 estrelas'}`,
                'Transfer aeroporto-hotel-aeroporto',
                'Seguro viagem',
                `${accommodation === 'premium' ? 'Tour privativo' : 'City tour'} pelos principais pontos turísticos`
            ]
        }
    ];
    
    // Adiciona opção com condições especiais se habilitado
    if (quotationState.specialConditionsEnabled) {
        options.push({
            id: 'special',
            title: `Pacote Exclusivo IGO Travel para ${destination}`,
            description: `Uma experiência única em ${destination} com condições especiais da IGO Travel, incluindo benefícios exclusivos e atendimento personalizado.`,
            price: totalPrice * 0.85, // 15% de desconto com condições especiais
            pricePerPerson: pricePerPerson * 0.85,
            currency: 'BRL',
            paymentType: 'special',
            specialCondition: true,
            highlights: [
                'Passagens aéreas de ida e volta',
                `Hospedagem em hotel ${accommodation === 'premium' ? '5 estrelas premium' : accommodation === 'comfort' ? '4 estrelas superior' : '3 estrelas plus'}`,
                'Transfer privativo aeroporto-hotel-aeroporto',
                'Seguro viagem com cobertura estendida',
                'Concierge exclusivo durante toda a viagem',
                'Experiências VIP selecionadas'
            ]
        });
    }
    
    // Adiciona opção híbrida (parte em dinheiro, parte em condições especiais)
    if (quotationState.specialConditionsEnabled) {
        options.push({
            id: 'hybrid',
            title: `Pacote Híbrido para ${destination}`,
            description: `Combine o melhor dos dois mundos: parte do pagamento em dinheiro e parte com condições especiais da IGO Travel.`,
            price: totalPrice * 0.6, // 60% do preço em dinheiro
            pricePerPerson: pricePerPerson * 0.6,
            currency: 'BRL',
            paymentType: 'hybrid',
            specialCondition: true,
            specialConditionAmount: Math.round(totalPrice * 0.4 * 100) / 100, // 40% do preço em condições especiais
            highlights: [
                'Passagens aéreas de ida e volta',
                `Hospedagem em hotel ${accommodation === 'premium' ? '5 estrelas' : accommodation === 'comfort' ? '4 estrelas' : '3 estrelas superior'}`,
                'Transfer aeroporto-hotel-aeroporto',
                'Seguro viagem com cobertura estendida',
                'Acesso a lounges exclusivos',
                'Experiências selecionadas no destino'
            ]
        });
    }
    
    return options;
}

// Renderiza os resultados da cotação
function renderQuotationResults(container) {
    // Cabeçalho dos resultados
    container.innerHTML = `
        <div class="quotation-results-header">
            <h2>Cotação para ${quotationState.destination}</h2>
            <p>Encontramos ${quotationState.quotationOptions.length} opções para sua viagem de ${formatDate(quotationState.dates.departure)} a ${formatDate(quotationState.dates.return)} para ${quotationState.travelers.adults} adulto(s)${quotationState.travelers.children > 0 ? `, ${quotationState.travelers.children} criança(s)` : ''}${quotationState.travelers.infants > 0 ? ` e ${quotationState.travelers.infants} bebê(s)` : ''}.</p>
        </div>
        <div class="quotation-options-container" id="quotation-options-list"></div>
        <div class="quotation-actions">
            <button class="btn-secondary" id="restart-quotation">
                <i class="fas fa-redo"></i> Nova Cotação
            </button>
            <button class="btn-primary" id="contact-consultant">
                <i class="fas fa-phone"></i> Falar com Consultor
            </button>
        </div>
    `;
    
    // Renderiza cada opção de cotação
    const optionsList = document.getElementById('quotation-options-list');
    quotationState.quotationOptions.forEach(option => {
        const optionCard = document.createElement('div');
        optionCard.className = `quotation-option-card ${option.specialCondition ? 'special-condition' : ''}`;
        optionCard.dataset.id = option.id;
        
        optionCard.innerHTML = `
            <div class="option-header">
                <h3>${option.title}</h3>
                ${option.specialCondition ? '<span class="special-badge">Condição Especial IGO Travel</span>' : ''}
            </div>
            <div class="option-content">
                <p class="option-description">${option.description}</p>
                
                <div class="option-price">
                    <div class="price-details">
                        <span class="price-label">Valor total:</span>
                        <span class="price-value">${formatCurrency(option.price, option.currency)}</span>
                        <span class="price-installment">ou 10x de ${formatCurrency(option.price / 10, option.currency)}</span>
                        ${option.paymentType === 'hybrid' ? `<span class="special-condition-amount">+ ${formatCurrency(option.specialConditionAmount, option.currency)} em Condições Especiais</span>` : ''}
                    </div>
                    <div class="price-per-person">
                        <span class="per-person-label">Valor por pessoa:</span>
                        <span class="per-person-value">${formatCurrency(option.pricePerPerson, option.currency)}</span>
                    </div>
                </div>
                
                <div class="option-highlights">
                    <h4>Incluso no Pacote:</h4>
                    <ul>
                        ${option.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
                    </ul>
                </div>
                
                ${option.specialCondition ? `
                <div class="special-condition-info">
                    <div class="info-icon"><i class="fas fa-info-circle"></i></div>
                    <div class="info-text">
                        <p>As Condições Especiais da IGO Travel oferecem benefícios exclusivos como upgrades, transfers privativos, experiências VIP e muito mais.</p>
                    </div>
                </div>
                ` : ''}
            </div>
            <div class="option-actions">
                <button class="btn-secondary btn-details" data-id="${option.id}">Ver Detalhes</button>
                <button class="btn-primary btn-select" data-id="${option.id}">Selecionar</button>
            </div>
        `;
        
        optionsList.appendChild(optionCard);
    });
    
    // Anexa event listeners
    document.getElementById('restart-quotation').addEventListener('click', () => {
        quotationState.currentStep = 0;
        quotationState.quotationOptions = [];
        updateQuotationUI();
    });
    
    document.getElementById('contact-consultant').addEventListener('click', () => {
        showContactForm();
    });
    
    document.querySelectorAll('.btn-select').forEach(button => {
        button.addEventListener('click', (e) => {
            const optionId = e.target.dataset.id;
            const selectedOption = quotationState.quotationOptions.find(opt => opt.id === optionId);
            if (selectedOption) {
                quotationState.selectedOption = selectedOption;
                showCheckout();
            }
        });
    });
    
    document.querySelectorAll('.btn-details').forEach(button => {
        button.addEventListener('click', (e) => {
            const optionId = e.target.dataset.id;
            const selectedOption = quotationState.quotationOptions.find(opt => opt.id === optionId);
            if (selectedOption) {
                showOptionDetails(selectedOption);
            }
        });
    });
}

// Formata valor monetário
function formatCurrency(value, currency) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: currency || 'BRL'
    }).format(value);
}

// Formata data
function formatDate(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Exibe detalhes de uma opção de cotação
function showOptionDetails(option) {
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    quotationContainer.innerHTML = `
        <div class="option-details">
            <div class="details-header">
                <h2>${option.title}</h2>
                ${option.specialCondition ? '<span class="special-badge">Condição Especial IGO Travel</span>' : ''}
            </div>
            
            <div class="details-content">
                <p class="details-description">${option.description}</p>
                
                <div class="details-price">
                    <div class="price-details">
                        <span class="price-label">Valor total:</span>
                        <span class="price-value">${formatCurrency(option.price, option.currency)}</span>
                        <span class="price-installment">ou 10x de ${formatCurrency(option.price / 10, option.currency)}</span>
                        ${option.paymentType === 'hybrid' ? `<span class="special-condition-amount">+ ${formatCurrency(option.specialConditionAmount, option.currency)} em Condições Especiais</span>` : ''}
                    </div>
                    <div class="price-per-person">
                        <span class="per-person-label">Valor por pessoa:</span>
                        <span class="per-person-value">${formatCurrency(option.pricePerPerson, option.currency)}</span>
                    </div>
                </div>
                
                <div class="details-section">
                    <h3>Incluso no Pacote:</h3>
                    <ul>
                        ${option.highlights.map(highlight => `<li>${highlight}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="details-section">
                    <h3>Informações da Viagem:</h3>
                    <div class="trip-info">
                        <div class="info-item">
                            <div class="info-label"><i class="fas fa-map-marker-alt"></i> Destino:</div>
                            <div class="info-value">${quotationState.destination}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label"><i class="fas fa-calendar-alt"></i> Período:</div>
                            <div class="info-value">${formatDate(quotationState.dates.departure)} a ${formatDate(quotationState.dates.return)}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label"><i class="fas fa-users"></i> Viajantes:</div>
                            <div class="info-value">${quotationState.travelers.adults} adulto(s)${quotationState.travelers.children > 0 ? `, ${quotationState.travelers.children} criança(s)` : ''}${quotationState.travelers.infants > 0 ? ` e ${quotationState.travelers.infants} bebê(s)` : ''}</div>
                        </div>
                    </div>
                </div>
                
                ${option.specialCondition ? `
                <div class="details-section">
                    <h3>Condições Especiais da IGO Travel:</h3>
                    <div class="special-conditions-details">
                        <p>As Condições Especiais da IGO Travel são um programa exclusivo que oferece benefícios diferenciados para nossos clientes, incluindo:</p>
                        <ul>
                            <li>Upgrades de acomodação (sujeito a disponibilidade)</li>
                            <li>Transfers privativos</li>
                            <li>Check-in prioritário</li>
                            <li>Acesso a lounges exclusivos</li>
                            <li>Experiências VIP no destino</li>
                            <li>Atendimento personalizado 24/7</li>
                        </ul>
                        ${option.paymentType === 'hybrid' ? `
                        <div class="hybrid-explanation">
                            <h4>Como funciona o Pacote Híbrido:</h4>
                            <p>Nesta opção, você paga ${formatCurrency(option.price, option.currency)} em dinheiro e utiliza o equivalente a ${formatCurrency(option.specialConditionAmount, option.currency)} em Condições Especiais da IGO Travel, totalizando ${formatCurrency(option.price + option.specialConditionAmount, option.currency)}.</p>
                        </div>
                        ` : ''}
                    </div>
                </div>
                ` : ''}
            </div>
            
            <div class="details-actions">
                <button class="btn-secondary" id="back-to-options">Voltar</button>
                <button class="btn-primary" id="select-option">Selecionar</button>
            </div>
        </div>
    `;
    
    // Event listeners
    document.getElementById('back-to-options').addEventListener('click', () => {
        updateQuotationUI();
    });
    
    document.getElementById('select-option').addEventListener('click', () => {
        quotationState.selectedOption = option;
        showCheckout();
    });
}

// Exibe formulário de checkout
function showCheckout() {
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    const option = quotationState.selectedOption;
    
    quotationContainer.innerHTML = `
        <div class="checkout-container">
            <div class="checkout-header">
                <h2>Finalizar Reserva</h2>
                <p>Complete suas informações para finalizar a reserva</p>
            </div>
            
            <div class="checkout-content">
                <div class="checkout-summary">
                    <h3>Resumo da Reserva</h3>
                    <div class="summary-details">
                        <div class="summary-item">
                            <div class="item-label">Pacote:</div>
                            <div class="item-value">${option.title}</div>
                        </div>
                        <div class="summary-item">
                            <div class="item-label">Destino:</div>
                            <div class="item-value">${quotationState.destination}</div>
                        </div>
                        <div class="summary-item">
                            <div class="item-label">Período:</div>
                            <div class="item-value">${formatDate(quotationState.dates.departure)} a ${formatDate(quotationState.dates.return)}</div>
                        </div>
                        <div class="summary-item">
                            <div class="item-label">Viajantes:</div>
                            <div class="item-value">${quotationState.travelers.adults} adulto(s)${quotationState.travelers.children > 0 ? `, ${quotationState.travelers.children} criança(s)` : ''}${quotationState.travelers.infants > 0 ? ` e ${quotationState.travelers.infants} bebê(s)` : ''}</div>
                        </div>
                        <div class="summary-item total-price">
                            <div class="item-label">Valor Total:</div>
                            <div class="item-value">${formatCurrency(option.price, option.currency)}</div>
                        </div>
                        ${option.paymentType === 'hybrid' ? `
                        <div class="summary-item special-condition-amount">
                            <div class="item-label">Condições Especiais:</div>
                            <div class="item-value">${formatCurrency(option.specialConditionAmount, option.currency)}</div>
                        </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="checkout-form">
                    <h3>Informações de Contato</h3>
                    <form id="checkout-form">
                        <div class="form-group">
                            <label for="contact-name">Nome completo</label>
                            <input type="text" id="contact-name" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="contact-email">E-mail</label>
                            <input type="email" id="contact-email" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="contact-phone">Telefone (WhatsApp)</label>
                            <input type="tel" id="contact-phone" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="contact-document">CPF ou Passaporte</label>
                            <input type="text" id="contact-document" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Forma de Pagamento</label>
                            <div class="payment-options">
                                <div class="payment-option">
                                    <input type="radio" name="payment-method" id="payment-credit" value="credit" checked>
                                    <label for="payment-credit">Cartão de Crédito</label>
                                </div>
                                <div class="payment-option">
                                    <input type="radio" name="payment-method" id="payment-pix" value="pix">
                                    <label for="payment-pix">PIX</label>
                                </div>
                                <div class="payment-option">
                                    <input type="radio" name="payment-method" id="payment-bank" value="bank">
                                    <label for="payment-bank">Transferência Bancária</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="terms-checkbox">
                                <input type="checkbox" id="terms-checkbox" required>
                                <label for="terms-checkbox">Li e concordo com os <a href="#">Termos e Condições</a> e <a href="#">Política de Privacidade</a></label>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="checkout-actions">
                <button class="btn-secondary" id="back-to-details">Voltar</button>
                <button class="btn-primary" id="complete-reservation">Finalizar Reserva</button>
            </div>
        </div>
    `;
    
    // Event listeners
    document.getElementById('back-to-details').addEventListener('click', () => {
        showOptionDetails(option);
    });
    
    document.getElementById('complete-reservation').addEventListener('click', () => {
        if (document.getElementById('checkout-form').checkValidity()) {
            completeReservation();
        } else {
            alert('Por favor, preencha todos os campos obrigatórios.');
        }
    });
}

// Finaliza a reserva
function completeReservation() {
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    // Exibe mensagem de sucesso
    quotationContainer.innerHTML = `
        <div class="success-message">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2>Reserva Realizada com Sucesso!</h2>
            <p>Sua reserva para ${quotationState.destination} foi realizada com sucesso. Em breve você receberá um e-mail com todos os detalhes da sua viagem.</p>
            <div class="reservation-number">
                <span>Número da Reserva:</span>
                <strong>IGO-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}</strong>
            </div>
            <div class="success-actions">
                <button class="btn-primary" id="back-to-home">Voltar para o Início</button>
            </div>
        </div>
    `;
    
    document.getElementById('back-to-home').addEventListener('click', () => {
        window.location.href = 'index.html';
    });
}

// Exibe formulário de contato
function showContactForm() {
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    quotationContainer.innerHTML = `
        <div class="contact-form-container">
            <h2>Fale com um Consultor</h2>
            <p>Preencha o formulário abaixo para que um de nossos consultores entre em contato com você.</p>
            
            <form id="contact-form" class="contact-form">
                <div class="form-group">
                    <label for="contact-name">Nome completo</label>
                    <input type="text" id="contact-name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contact-email">E-mail</label>
                    <input type="email" id="contact-email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contact-phone">Telefone (WhatsApp)</label>
                    <input type="tel" id="contact-phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contact-message">Mensagem (opcional)</label>
                    <textarea id="contact-message" class="form-control" rows="4"></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-secondary" id="back-to-quotation">Voltar</button>
                    <button type="submit" class="btn-primary">Enviar</button>
                </div>
            </form>
        </div>
    `;
    
    // Event listeners
    document.getElementById('back-to-quotation').addEventListener('click', () => {
        updateQuotationUI();
    });
    
    document.getElementById('contact-form').addEventListener('submit', (e) => {
        e.preventDefault();
        submitContactForm();
    });
}

// Envia formulário de contato
function submitContactForm() {
    // Simula envio do formulário
    const contactForm = document.getElementById('contact-form');
    const formData = new FormData(contactForm);
    
    // Exibe mensagem de sucesso
    const quotationContainer = document.getElementById('quotation-container');
    if (!quotationContainer) return;
    
    quotationContainer.innerHTML = `
        <div class="success-message">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2>Solicitação Enviada com Sucesso!</h2>
            <p>Obrigado por entrar em contato conosco. Um de nossos consultores entrará em contato com você em breve.</p>
            <button class="btn-primary" id="back-to-home">Voltar para o Início</button>
        </div>
    `;
    
    document.getElementById('back-to-home').addEventListener('click', () => {
        window.location.href = 'index.html';
    });
}

// Inicializa o sistema de cotação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initQuotation();
});
