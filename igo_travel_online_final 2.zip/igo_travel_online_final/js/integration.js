/**
 * Sistema de Integração Hub-Toronto e Missão da Semana
 * Hub IGO Travel
 */

// Estado do sistema de integração e missões
let integrationState = {
    // Informações do motorista (exemplo)
    driverInfo: {
        id: 'D-901234',
        name: 'João Silva',
        rating: 4.8,
        status: 'online',
        vehicle: 'Toyota Corolla (2023)',
        licensePlate: 'ABC-1234',
        profileImage: 'https://via.placeholder.com/150',
        joinDate: '2023-05-15'
    },
    
    // Missão da semana atual
    currentMission: {
        id: 'MSW-2025-16',
        title: 'Missão da Semana',
        description: 'Complete 5 corridas para ganhar CAD $25',
        startDate: '2025-04-15',
        endDate: '2025-04-21',
        targetRides: 5,
        reward: 25.00,
        currency: 'CAD',
        progress: 3,
        completed: false,
        termsAndConditions: 'Válido para corridas realizadas entre 15/04/2025 e 21/04/2025. O bônus será creditado automaticamente após a conclusão da meta.'
    },
    
    // Histórico de missões
    missionHistory: [
        {
            id: 'MSW-2025-15',
            title: 'Missão da Semana',
            description: 'Complete 5 corridas para ganhar CAD $25',
            startDate: '2025-04-08',
            endDate: '2025-04-14',
            targetRides: 5,
            reward: 25.00,
            currency: 'CAD',
            progress: 5,
            completed: true,
            completionDate: '2025-04-13',
            bonusPaid: true
        },
        {
            id: 'MSW-2025-14',
            title: 'Missão da Semana',
            description: 'Complete 10 corridas para ganhar CAD $60',
            startDate: '2025-04-01',
            endDate: '2025-04-07',
            targetRides: 10,
            reward: 60.00,
            currency: 'CAD',
            progress: 7,
            completed: false
        },
        {
            id: 'MSW-2025-13',
            title: 'Missão da Semana',
            description: 'Complete 5 corridas para ganhar CAD $25',
            startDate: '2025-03-25',
            endDate: '2025-03-31',
            targetRides: 5,
            reward: 25.00,
            currency: 'CAD',
            progress: 5,
            completed: true,
            completionDate: '2025-03-30',
            bonusPaid: true
        }
    ],
    
    // Próximos serviços (transfers)
    upcomingTransfers: [
        {
            id: 'TRF-001',
            date: '2025-04-17',
            time: '14:30',
            pickupLocation: 'Aeroporto Internacional de Toronto',
            dropoffLocation: 'Hotel Sheraton Centre Toronto',
            client: 'Maria Santos',
            clientContact: '+1 (416) 555-1234',
            status: 'confirmed',
            price: 125.00,
            currency: 'CAD',
            notes: 'Cliente solicitou ajuda com 2 malas grandes'
        },
        {
            id: 'TRF-002',
            date: '2025-04-18',
            time: '09:00',
            pickupLocation: 'Hotel Sheraton Centre Toronto',
            dropoffLocation: 'CN Tower e Aquário Ripley',
            client: 'Carlos Oliveira',
            clientContact: '+1 (416) 555-5678',
            status: 'pending',
            price: 195.50,
            currency: 'CAD',
            notes: 'City Tour - Família com 2 crianças'
        }
    ],
    
    // Configurações de integração
    integrationSettings: {
        syncEnabled: true,
        autoAcceptTransfers: false,
        notificationsEnabled: true,
        lastSyncTime: '2025-04-16T18:30:45Z'
    }
};

// Inicializa o sistema de integração
function initIntegration() {
    const missionContainer = document.getElementById('mission-container');
    const transfersContainer = document.getElementById('transfers-container');
    
    if (missionContainer) {
        renderMissionUI(missionContainer);
    }
    
    if (transfersContainer) {
        renderTransfersUI(transfersContainer);
    }
    
    attachEventListeners();
}

// Renderiza a interface da Missão da Semana
function renderMissionUI(container) {
    const mission = integrationState.currentMission;
    const progressPercentage = (mission.progress / mission.targetRides) * 100;
    
    // Cabeçalho da missão
    const header = document.createElement('div');
    header.className = 'mission-header';
    header.innerHTML = `
        <div class="mission-title">
            <h2><i class="fas fa-trophy"></i> ${mission.title}</h2>
            <p>Período: ${formatDate(mission.startDate)} a ${formatDate(mission.endDate)}</p>
        </div>
    `;
    container.appendChild(header);
    
    // Card da missão atual
    const missionCard = document.createElement('div');
    missionCard.className = `mission-card ${mission.completed ? 'completed' : ''}`;
    missionCard.innerHTML = `
        <div class="mission-content">
            <div class="mission-description">
                <h3>${mission.description}</h3>
                <p class="mission-period">Válido até ${formatDate(mission.endDate)}</p>
            </div>
            
            <div class="mission-progress">
                <div class="progress-text">
                    <span>Progresso: ${mission.progress} de ${mission.targetRides} corridas</span>
                    <span class="progress-percentage">${Math.round(progressPercentage)}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progressPercentage}%"></div>
                </div>
                <p class="progress-message">${getProgressMessage(mission)}</p>
            </div>
            
            ${mission.completed ? `
                <div class="mission-completed">
                    <div class="completed-badge">
                        <i class="fas fa-check-circle"></i> MISSÃO CUMPRIDA
                    </div>
                    <p class="reward-message">Bônus de ${formatCurrency(mission.reward, mission.currency)} adicionado ao seu saldo!</p>
                </div>
            ` : ''}
        </div>
        
        <div class="mission-actions">
            <button class="btn-secondary" id="view-terms">Ver Termos</button>
            <button class="btn-primary" id="view-mission-history">Histórico de Missões</button>
        </div>
    `;
    container.appendChild(missionCard);
}

// Renderiza a interface de Transfers
function renderTransfersUI(container) {
    // Cabeçalho dos transfers
    const header = document.createElement('div');
    header.className = 'transfers-header';
    header.innerHTML = `
        <div class="transfers-title">
            <h2><i class="fas fa-car"></i> Próximos Serviços</h2>
            <p>Transfers e serviços agendados</p>
        </div>
        <div class="transfers-actions">
            <button class="btn-primary" id="sync-transfers">
                <i class="fas fa-sync-alt"></i> Sincronizar
            </button>
        </div>
    `;
    container.appendChild(header);
    
    // Lista de transfers
    const transfersList = document.createElement('div');
    transfersList.className = 'transfers-list';
    
    if (integrationState.upcomingTransfers.length === 0) {
        transfersList.innerHTML = `
            <div class="no-transfers">
                <div class="empty-icon"><i class="fas fa-calendar-times"></i></div>
                <p>Você não tem serviços agendados no momento.</p>
            </div>
        `;
    } else {
        integrationState.upcomingTransfers.forEach(transfer => {
            const transferItem = document.createElement('div');
            transferItem.className = `transfer-item ${transfer.status}`;
            transferItem.innerHTML = `
                <div class="transfer-date-time">
                    <div class="transfer-date">${formatDate(transfer.date)}</div>
                    <div class="transfer-time">${transfer.time}</div>
                </div>
                
                <div class="transfer-details">
                    <div class="transfer-route">
                        <div class="pickup-location">
                            <i class="fas fa-map-marker-alt"></i> ${transfer.pickupLocation}
                        </div>
                        <div class="route-arrow"><i class="fas fa-long-arrow-alt-down"></i></div>
                        <div class="dropoff-location">
                            <i class="fas fa-flag-checkered"></i> ${transfer.dropoffLocation}
                        </div>
                    </div>
                    
                    <div class="transfer-client-info">
                        <div class="client-name"><i class="fas fa-user"></i> ${transfer.client}</div>
                        <div class="client-contact"><i class="fas fa-phone"></i> ${transfer.clientContact}</div>
                    </div>
                </div>
                
                <div class="transfer-status-price">
                    <div class="transfer-status ${transfer.status}">
                        ${transfer.status === 'confirmed' ? '<i class="fas fa-check-circle"></i> Confirmado' : '<i class="fas fa-clock"></i> Pendente'}
                    </div>
                    <div class="transfer-price">
                        ${formatCurrency(transfer.price, transfer.currency)}
                    </div>
                </div>
                
                <div class="transfer-actions">
                    <button class="btn-primary btn-sm" data-id="${transfer.id}">
                        ${transfer.status === 'confirmed' ? 'Ver Detalhes' : 'Confirmar'}
                    </button>
                </div>
            `;
            transfersList.appendChild(transferItem);
        });
    }
    
    container.appendChild(transfersList);
}

// Anexa event listeners aos elementos interativos
function attachEventListeners() {
    // Botão de visualizar termos da missão
    const viewTermsButton = document.getElementById('view-terms');
    if (viewTermsButton) {
        viewTermsButton.addEventListener('click', () => {
            showMissionTermsModal();
        });
    }
    
    // Botão de visualizar histórico de missões
    const viewHistoryButton = document.getElementById('view-mission-history');
    if (viewHistoryButton) {
        viewHistoryButton.addEventListener('click', () => {
            showMissionHistoryModal();
        });
    }
    
    // Botão de sincronizar transfers
    const syncTransfersButton = document.getElementById('sync-transfers');
    if (syncTransfersButton) {
        syncTransfersButton.addEventListener('click', () => {
            syncTransfers();
        });
    }
    
    // Botões de ação dos transfers
    const transferActionButtons = document.querySelectorAll('.transfer-actions button');
    transferActionButtons.forEach(button => {
        button.addEventListener('click', () => {
            const transferId = button.dataset.id;
            const transfer = integrationState.upcomingTransfers.find(t => t.id === transferId);
            
            if (transfer) {
                if (transfer.status === 'pending') {
                    confirmTransfer(transferId);
                } else {
                    showTransferDetailsModal(transfer);
                }
            }
        });
    });
}

// Exibe modal com os termos da missão
function showMissionTermsModal() {
    const mission = integrationState.currentMission;
    
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content mission-terms-modal';
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>Termos e Condições da Missão</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="mission-terms-content">
                <h4>${mission.title}: ${mission.description}</h4>
                <p class="mission-period">Período: ${formatDate(mission.startDate)} a ${formatDate(mission.endDate)}</p>
                
                <div class="terms-section">
                    <h5>Como Funciona</h5>
                    <p>Complete ${mission.targetRides} corridas dentro do período da missão para ganhar um bônus de ${formatCurrency(mission.reward, mission.currency)}.</p>
                </div>
                
                <div class="terms-section">
                    <h5>Regras</h5>
                    <ul>
                        <li>Apenas corridas completadas com sucesso contam para a missão.</li>
                        <li>Corridas canceladas não são contabilizadas.</li>
                        <li>O bônus é creditado automaticamente no seu saldo após atingir a meta.</li>
                        <li>Você pode acompanhar seu progresso em tempo real no painel do motorista.</li>
                    </ul>
                </div>
                
                <div class="terms-section">
                    <h5>Termos Adicionais</h5>
                    <p>${mission.termsAndConditions}</p>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-primary" id="close-terms">Entendi</button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Anexa event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const closeTermsButton = document.getElementById('close-terms');
    closeTermsButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
}

// Exibe modal com o histórico de missões
function showMissionHistoryModal() {
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content mission-history-modal';
    
    let historyContent = '';
    
    integrationState.missionHistory.forEach(mission => {
        historyContent += `
            <div class="history-item ${mission.completed ? 'completed' : 'incomplete'}">
                <div class="history-period">
                    <span class="period-dates">${formatDate(mission.startDate)} a ${formatDate(mission.endDate)}</span>
                </div>
                
                <div class="history-details">
                    <div class="history-description">${mission.description}</div>
                    <div class="history-progress">Progresso: ${mission.progress}/${mission.targetRides} corridas</div>
                </div>
                
                <div class="history-status">
                    ${mission.completed ? 
                        `<div class="status-completed">
                            <i class="fas fa-check-circle"></i> Concluída
                            <div class="bonus-paid">${formatCurrency(mission.reward, mission.currency)} recebido</div>
                        </div>` : 
                        `<div class="status-incomplete">
                            <i class="fas fa-times-circle"></i> Não concluída
                        </div>`
                    }
                </div>
            </div>
        `;
    });
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>Histórico de Missões</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="mission-history-content">
                ${historyContent.length > 0 ? historyContent : `
                    <div class="no-history">
                        <div class="empty-icon"><i class="fas fa-history"></i></div>
                        <p>Você ainda não participou de nenhuma missão.</p>
                    </div>
                `}
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-primary" id="close-history">Fechar</button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Anexa event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const closeHistoryButton = document.getElementById('close-history');
    closeHistoryButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
}

// Exibe modal com detalhes do transfer
function showTransferDetailsModal(transfer) {
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content transfer-details-modal';
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>Detalhes do Serviço</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="transfer-details-content">
                <div class="transfer-id-date">
                    <div class="transfer-id">ID: ${transfer.id}</div>
                    <div class="transfer-date-time">${formatDate(transfer.date)} às ${transfer.time}</div>
                </div>
                
                <div class="transfer-route-details">
                    <div class="route-point pickup">
                        <div class="point-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="point-details">
                            <div class="point-label">Local de Embarque:</div>
                            <div class="point-value">${transfer.pickupLocation}</div>
                        </div>
                    </div>
                    
                    <div class="route-connector">
                        <div class="connector-line"></div>
                    </div>
                    
                    <div class="route-point dropoff">
                        <div class="point-icon"><i class="fas fa-flag-checkered"></i></div>
                        <div class="point-details">
                            <div class="point-label">Local de Desembarque:</div>
                            <div class="point-value">${transfer.dropoffLocation}</div>
                        </div>
                    </div>
                </div>
                
                <div class="transfer-client-details">
                    <h4>Informações do Cliente</h4>
                    <div class="client-detail">
                        <div class="detail-label"><i class="fas fa-user"></i> Nome:</div>
                        <div class="detail-value">${transfer.client}</div>
                    </div>
                    <div class="client-detail">
                        <div class="detail-label"><i class="fas fa-phone"></i> Contato:</div>
                        <div class="detail-value">${transfer.clientContact}</div>
                    </div>
                </div>
                
                <div class="transfer-payment-details">
                    <h4>Informações de Pagamento</h4>
                    <div class="payment-detail">
                        <div class="detail-label">Valor:</div>
                        <div class="detail-value">${formatCurrency(transfer.price, transfer.currency)}</div>
                    </div>
                    <div class="payment-detail">
                        <div class="detail-label">Status:</div>
                        <div class="detail-value status-${transfer.status}">
                            ${transfer.status === 'confirmed' ? 'Confirmado' : 'Pendente'}
                        </div>
                    </div>
                </div>
                
                ${transfer.notes ? `
                    <div class="transfer-notes">
                        <h4>Observações</h4>
                        <p>${transfer.notes}</p>
                    </div>
                ` : ''}
                
                <div class="transfer-map">
                    <div class="map-placeholder">
                        <i class="fas fa-map"></i>
                        <span>Mapa do trajeto</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-secondary" id="close-transfer-details">Fechar</button>
            <button class="btn-primary" id="navigate-transfer">Iniciar Navegação</button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Anexa event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const closeDetailsButton = document.getElementById('close-transfer-details');
    closeDetailsButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const navigateButton = document.getElementById('navigate-transfer');
    navigateButton.addEventListener('click', () => {
        // Simulação de abertura de navegação
        alert('Iniciando navegação para: ' + transfer.pickupLocation);
        document.body.removeChild(modalOverlay);
    });
}

// Confirma um transfer pendente
function confirmTransfer(transferId) {
    const transferIndex = integrationState.upcomingTransfers.findIndex(t => t.id === transferId);
    
    if (transferIndex !== -1) {
        // Atualiza o status do transfer
        integrationState.upcomingTransfers[transferIndex].status = 'confirmed';
        
        // Atualiza a interface
        const transfersContainer = document.getElementById('transfers-container');
        if (transfersContainer) {
            transfersContainer.innerHTML = '';
            renderTransfersUI(transfersContainer);
            attachEventListeners();
        }
        
        // Exibe mensagem de confirmação
        showConfirmationMessage('Transfer confirmado com sucesso!');
        
        // Incrementa o progresso da missão (simulação)
        updateMissionProgress();
    }
}

// Sincroniza transfers com o servidor
function syncTransfers() {
    // Simulação de sincronização
    showLoadingOverlay('Sincronizando dados...');
    
    // Simula um tempo de processamento
    setTimeout(() => {
        // Atualiza a hora da última sincronização
        integrationState.integrationSettings.lastSyncTime = new Date().toISOString();
        
        // Atualiza a interface
        const transfersContainer = document.getElementById('transfers-container');
        if (transfersContainer) {
            transfersContainer.innerHTML = '';
            renderTransfersUI(transfersContainer);
            attachEventListeners();
        }
        
        // Remove o overlay de carregamento
        hideLoadingOverlay();
        
        // Exibe mensagem de sucesso
        showConfirmationMessage('Dados sincronizados com sucesso!');
    }, 1500);
}

// Atualiza o progresso da missão (simulação)
function updateMissionProgress() {
    // Incrementa o progresso
    integrationState.currentMission.progress += 1;
    
    // Verifica se a missão foi concluída
    if (integrationState.currentMission.progress >= integrationState.currentMission.targetRides && !integrationState.currentMission.completed) {
        integrationState.currentMission.completed = true;
        
        // Simula o crédito do bônus
        creditMissionBonus();
    }
    
    // Atualiza a interface
    const missionContainer = document.getElementById('mission-container');
    if (missionContainer) {
        missionContainer.innerHTML = '';
        renderMissionUI(missionContainer);
        attachEventListeners();
    }
}

// Credita o bônus da missão (simulação)
function creditMissionBonus() {
    // Exibe notificação de missão concluída
    showMissionCompletedNotification();
}

// Exibe notificação de missão concluída
function showMissionCompletedNotification() {
    const mission = integrationState.currentMission;
    
    // Cria o elemento da notificação
    const notification = document.createElement('div');
    notification.className = 'mission-completed-notification';
    
    notification.innerHTML = `
        <div class="notification-icon">
            <i class="fas fa-trophy"></i>
        </div>
        <div class="notification-content">
            <h3>Missão Concluída!</h3>
            <p>Você completou a Missão da Semana e ganhou ${formatCurrency(mission.reward, mission.currency)}!</p>
        </div>
        <button class="notification-close">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    // Anexa event listener para fechar
    const closeButton = notification.querySelector('.notification-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(notification);
    });
    
    // Remove automaticamente após alguns segundos
    setTimeout(() => {
        if (document.body.contains(notification)) {
            document.body.removeChild(notification);
        }
    }, 5000);
}

// Exibe mensagem de confirmação
function showConfirmationMessage(message) {
    // Cria o elemento da mensagem
    const messageElement = document.createElement('div');
    messageElement.className = 'confirmation-message';
    
    messageElement.innerHTML = `
        <div class="message-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="message-text">${message}</div>
    `;
    
    document.body.appendChild(messageElement);
    
    // Remove automaticamente após alguns segundos
    setTimeout(() => {
        if (document.body.contains(messageElement)) {
            document.body.removeChild(messageElement);
        }
    }, 3000);
}

// Exibe overlay de carregamento
function showLoadingOverlay(message) {
    // Cria o elemento do overlay
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.id = 'loading-overlay';
    
    overlay.innerHTML = `
        <div class="loading-spinner"></div>
        <div class="loading-message">${message}</div>
    `;
    
    document.body.appendChild(overlay);
}

// Remove overlay de carregamento
function hideLoadingOverlay() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        document.body.removeChild(overlay);
    }
}

// Obtém mensagem de progresso personalizada
function getProgressMessage(mission) {
    if (mission.completed) {
        return 'Parabéns! Você concluiu a missão desta semana.';
    }
    
    const remaining = mission.targetRides - mission.progress;
    
    if (remaining === 1) {
        return `Falta apenas 1 corrida para completar a missão e ganhar ${formatCurrency(mission.reward, mission.currency)}!`;
    } else if (remaining <= 3) {
        return `Faltam apenas ${remaining} corridas para completar a missão!`;
    } else {
        return `Complete mais ${remaining} corridas para ganhar ${formatCurrency(mission.reward, mission.currency)}.`;
    }
}

// Formata data
function formatDate(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Formata valor monetário
function formatCurrency(value, currency) {
    let currencySymbol = '';
    
    switch (currency) {
        case 'CAD':
            currencySymbol = 'CAD $';
            break;
        case 'USD':
            currencySymbol = 'US $';
            break;
        case 'BRL':
            currencySymbol = 'R$';
            break;
        default:
            currencySymbol = '$';
    }
    
    return `${currencySymbol}${value.toFixed(2)}`;
}

// Inicializa o sistema de integração quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initIntegration();
});
