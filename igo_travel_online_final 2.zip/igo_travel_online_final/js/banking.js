/**
 * Sistema Bancário para Motoristas
 * Hub IGO Travel
 */

// Estado do sistema bancário
let bankingState = {
    driverInfo: {
        id: 'D-901234',
        name: 'João Silva',
        rating: 4.8,
        status: 'online',
        vehicle: 'Toyota Corolla (2023)',
        licensePlate: 'ABC-1234',
        profileImage: 'https://via.placeholder.com/150',
        joinDate: '2023-05-15'
    },
    accountInfo: {
        balance: 1250.75,
        pendingBalance: 320.50,
        totalEarnings: 15780.25,
        withdrawalsCount: 12,
        lastWithdrawal: {
            date: '2025-04-10',
            amount: 500.00,
            status: 'completed'
        }
    },
    transactions: [
        {
            id: 'TRX-001',
            date: '2025-04-15',
            type: 'earning',
            description: 'Transfer Aeroporto → Hotel',
            amount: 120.50,
            status: 'completed'
        },
        {
            id: 'TRX-002',
            date: '2025-04-14',
            type: 'earning',
            description: 'City Tour - Centro Histórico',
            amount: 200.00,
            status: 'completed'
        },
        {
            id: 'TRX-003',
            date: '2025-04-10',
            type: 'withdrawal',
            description: 'Saque Express',
            amount: -500.00,
            status: 'completed'
        },
        {
            id: 'TRX-004',
            date: '2025-04-05',
            type: 'earning',
            description: 'Transfer Hotel → Restaurante',
            amount: 85.00,
            status: 'completed'
        },
        {
            id: 'TRX-005',
            date: '2025-04-03',
            type: 'earning',
            description: 'Transfer Aeroporto → Hotel',
            amount: 115.25,
            status: 'completed'
        },
        {
            id: 'TRX-006',
            date: '2025-04-01',
            type: 'bonus',
            description: 'Bônus de Avaliação 5 Estrelas',
            amount: 50.00,
            status: 'completed'
        },
        {
            id: 'TRX-007',
            date: '2025-03-28',
            type: 'withdrawal',
            description: 'Saque Regular',
            amount: -300.00,
            status: 'completed'
        }
    ],
    pendingTransfers: [
        {
            id: 'PTF-001',
            date: '2025-04-17',
            description: 'Transfer Aeroporto → Hotel',
            pickupTime: '14:30',
            client: 'Maria Santos',
            amount: 125.00,
            status: 'pending'
        },
        {
            id: 'PTF-002',
            date: '2025-04-18',
            description: 'City Tour - Parques',
            pickupTime: '09:00',
            client: 'Carlos Oliveira',
            amount: 195.50,
            status: 'confirmed'
        }
    ],
    withdrawalRules: {
        expressMinimum: 100.00,
        regularWaitingDays: 5,
        maxWithdrawalPerMonth: 5000.00,
        withdrawalFee: 0.00,
        availableMethods: ['PIX', 'Transferência Bancária', 'PayPal']
    }
};

// Inicializa o sistema bancário
function initBankingSystem() {
    const bankingContainer = document.getElementById('banking-container');
    if (!bankingContainer) return;
    
    renderBankingUI(bankingContainer);
    attachEventListeners();
}

// Renderiza a interface do sistema bancário
function renderBankingUI(container) {
    // Cabeçalho do sistema bancário
    const header = document.createElement('div');
    header.className = 'banking-header';
    header.innerHTML = `
        <div class="banking-title">
            <h2><i class="fas fa-university"></i> Mini Banco IGO</h2>
            <p>Gerencie seus ganhos e saques</p>
        </div>
    `;
    container.appendChild(header);
    
    // Resumo da conta
    const accountSummary = document.createElement('div');
    accountSummary.className = 'account-summary';
    accountSummary.innerHTML = `
        <div class="balance-card">
            <div class="balance-header">
                <h3>Saldo Disponível</h3>
                <span class="balance-amount">R$ ${bankingState.accountInfo.balance.toFixed(2)}</span>
            </div>
            <div class="balance-actions">
                <button class="btn-primary" id="withdraw-button">
                    <i class="fas fa-money-bill-wave"></i> Solicitar Saque
                </button>
            </div>
        </div>
        
        <div class="summary-cards">
            <div class="summary-card">
                <div class="card-icon"><i class="fas fa-clock"></i></div>
                <div class="card-content">
                    <h4>Saldo Pendente</h4>
                    <span class="card-value">R$ ${bankingState.accountInfo.pendingBalance.toFixed(2)}</span>
                </div>
            </div>
            
            <div class="summary-card">
                <div class="card-icon"><i class="fas fa-chart-line"></i></div>
                <div class="card-content">
                    <h4>Ganhos Totais</h4>
                    <span class="card-value">R$ ${bankingState.accountInfo.totalEarnings.toFixed(2)}</span>
                </div>
            </div>
            
            <div class="summary-card">
                <div class="card-icon"><i class="fas fa-calendar-check"></i></div>
                <div class="card-content">
                    <h4>Próximos Serviços</h4>
                    <span class="card-value">${bankingState.pendingTransfers.length}</span>
                </div>
            </div>
        </div>
    `;
    container.appendChild(accountSummary);
    
    // Abas de navegação
    const tabs = document.createElement('div');
    tabs.className = 'banking-tabs';
    tabs.innerHTML = `
        <div class="tab active" data-tab="transactions">Extrato</div>
        <div class="tab" data-tab="pending-transfers">Próximos Serviços</div>
        <div class="tab" data-tab="withdrawal-history">Histórico de Saques</div>
    `;
    container.appendChild(tabs);
    
    // Conteúdo das abas
    const tabContent = document.createElement('div');
    tabContent.className = 'tab-content';
    tabContent.id = 'tab-content';
    tabContent.innerHTML = renderTransactionsTab();
    container.appendChild(tabContent);
}

// Renderiza a aba de transações
function renderTransactionsTab() {
    return `
        <div class="transactions-container">
            <div class="transactions-header">
                <h3>Extrato de Transações</h3>
                <div class="transactions-filter">
                    <select id="transaction-filter">
                        <option value="all">Todas as Transações</option>
                        <option value="earning">Ganhos</option>
                        <option value="withdrawal">Saques</option>
                        <option value="bonus">Bônus</option>
                    </select>
                </div>
            </div>
            
            <div class="transactions-list">
                ${bankingState.transactions.map(transaction => `
                    <div class="transaction-item ${transaction.type}">
                        <div class="transaction-date">
                            <span class="date">${formatDate(transaction.date)}</span>
                            <span class="time">${transaction.id}</span>
                        </div>
                        <div class="transaction-details">
                            <div class="transaction-description">${transaction.description}</div>
                            <div class="transaction-status">${transaction.status === 'completed' ? 'Concluído' : 'Pendente'}</div>
                        </div>
                        <div class="transaction-amount ${transaction.amount < 0 ? 'negative' : 'positive'}">
                            ${transaction.amount < 0 ? '-' : '+'} R$ ${Math.abs(transaction.amount).toFixed(2)}
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Renderiza a aba de serviços pendentes
function renderPendingTransfersTab() {
    return `
        <div class="pending-transfers-container">
            <div class="pending-transfers-header">
                <h3>Próximos Serviços</h3>
            </div>
            
            <div class="pending-transfers-list">
                ${bankingState.pendingTransfers.map(transfer => `
                    <div class="transfer-item ${transfer.status}">
                        <div class="transfer-date">
                            <span class="date">${formatDate(transfer.date)}</span>
                            <span class="time">${transfer.pickupTime}</span>
                        </div>
                        <div class="transfer-details">
                            <div class="transfer-description">${transfer.description}</div>
                            <div class="transfer-client">Cliente: ${transfer.client}</div>
                            <div class="transfer-status">${transfer.status === 'pending' ? 'Aguardando Confirmação' : 'Confirmado'}</div>
                        </div>
                        <div class="transfer-amount">
                            R$ ${transfer.amount.toFixed(2)}
                        </div>
                        <div class="transfer-actions">
                            <button class="btn-primary btn-sm" data-id="${transfer.id}">
                                ${transfer.status === 'pending' ? 'Confirmar' : 'Ver Detalhes'}
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Renderiza a aba de histórico de saques
function renderWithdrawalHistoryTab() {
    const withdrawals = bankingState.transactions.filter(transaction => transaction.type === 'withdrawal');
    
    return `
        <div class="withdrawal-history-container">
            <div class="withdrawal-history-header">
                <h3>Histórico de Saques</h3>
            </div>
            
            <div class="withdrawal-history-list">
                ${withdrawals.length > 0 ? withdrawals.map(withdrawal => `
                    <div class="withdrawal-item">
                        <div class="withdrawal-date">
                            <span class="date">${formatDate(withdrawal.date)}</span>
                            <span class="time">${withdrawal.id}</span>
                        </div>
                        <div class="withdrawal-details">
                            <div class="withdrawal-description">${withdrawal.description}</div>
                            <div class="withdrawal-status">${withdrawal.status === 'completed' ? 'Concluído' : 'Pendente'}</div>
                        </div>
                        <div class="withdrawal-amount">
                            R$ ${Math.abs(withdrawal.amount).toFixed(2)}
                        </div>
                    </div>
                `).join('') : `
                    <div class="no-withdrawals">
                        <div class="empty-icon"><i class="fas fa-piggy-bank"></i></div>
                        <p>Você ainda não realizou nenhum saque.</p>
                    </div>
                `}
            </div>
        </div>
    `;
}

// Anexa event listeners aos elementos interativos
function attachEventListeners() {
    // Botão de saque
    const withdrawButton = document.getElementById('withdraw-button');
    if (withdrawButton) {
        withdrawButton.addEventListener('click', () => {
            showWithdrawalModal();
        });
    }
    
    // Abas de navegação
    const tabs = document.querySelectorAll('.banking-tabs .tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove a classe active de todas as abas
            tabs.forEach(t => t.classList.remove('active'));
            
            // Adiciona a classe active à aba clicada
            tab.classList.add('active');
            
            // Atualiza o conteúdo da aba
            const tabName = tab.dataset.tab;
            updateTabContent(tabName);
        });
    });
    
    // Filtro de transações
    const transactionFilter = document.getElementById('transaction-filter');
    if (transactionFilter) {
        transactionFilter.addEventListener('change', () => {
            filterTransactions(transactionFilter.value);
        });
    }
}

// Atualiza o conteúdo da aba selecionada
function updateTabContent(tabName) {
    const tabContent = document.getElementById('tab-content');
    if (!tabContent) return;
    
    switch (tabName) {
        case 'transactions':
            tabContent.innerHTML = renderTransactionsTab();
            // Reaplica o filtro se existir
            const transactionFilter = document.getElementById('transaction-filter');
            if (transactionFilter) {
                transactionFilter.addEventListener('change', () => {
                    filterTransactions(transactionFilter.value);
                });
            }
            break;
        
        case 'pending-transfers':
            tabContent.innerHTML = renderPendingTransfersTab();
            // Adiciona event listeners aos botões de ação
            const transferButtons = document.querySelectorAll('.transfer-actions button');
            transferButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const transferId = button.dataset.id;
                    const transfer = bankingState.pendingTransfers.find(t => t.id === transferId);
                    if (transfer) {
                        showTransferDetailsModal(transfer);
                    }
                });
            });
            break;
        
        case 'withdrawal-history':
            tabContent.innerHTML = renderWithdrawalHistoryTab();
            break;
    }
}

// Filtra as transações por tipo
function filterTransactions(filterType) {
    const transactionItems = document.querySelectorAll('.transaction-item');
    
    if (filterType === 'all') {
        transactionItems.forEach(item => {
            item.style.display = 'flex';
        });
    } else {
        transactionItems.forEach(item => {
            if (item.classList.contains(filterType)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
}

// Exibe o modal de saque
function showWithdrawalModal() {
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content withdrawal-modal';
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>Solicitar Saque</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="withdrawal-info">
                <div class="info-item">
                    <span class="info-label">Saldo Disponível:</span>
                    <span class="info-value">R$ ${bankingState.accountInfo.balance.toFixed(2)}</span>
                </div>
            </div>
            
            <div class="withdrawal-options">
                <div class="option-tabs">
                    <div class="option-tab active" data-option="express">Saque Express</div>
                    <div class="option-tab" data-option="regular">Saque Regular</div>
                </div>
                
                <div class="option-content" id="option-content">
                    <div class="express-option">
                        <div class="option-description">
                            <p><strong>Saque Express:</strong> Receba seu dinheiro em até 24 horas.</p>
                            <p class="option-note">Valor mínimo: R$ ${bankingState.withdrawalRules.expressMinimum.toFixed(2)}</p>
                        </div>
                        
                        <div class="form-group">
                            <label for="express-amount">Valor do Saque</label>
                            <input type="number" id="express-amount" class="form-control" min="${bankingState.withdrawalRules.expressMinimum}" max="${bankingState.accountInfo.balance}" step="0.01" value="${Math.max(bankingState.withdrawalRules.expressMinimum, Math.min(bankingState.accountInfo.balance, 100)).toFixed(2)}">
                            <div class="amount-error" id="express-amount-error"></div>
                        </div>
                    </div>
                </div>
                
                <div class="withdrawal-method">
                    <h4>Método de Saque</h4>
                    <div class="method-options">
                        ${bankingState.withdrawalRules.availableMethods.map((method, index) => `
                            <div class="method-option">
                                <input type="radio" name="withdrawal-method" id="method-${index}" value="${method}" ${index === 0 ? 'checked' : ''}>
                                <label for="method-${index}">${method}</label>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-secondary" id="cancel-withdrawal">Cancelar</button>
            <button class="btn-primary" id="confirm-withdrawal">Confirmar Saque</button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Anexa event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const cancelButton = document.getElementById('cancel-withdrawal');
    cancelButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const confirmButton = document.getElementById('confirm-withdrawal');
    confirmButton.addEventListener('click', () => {
        processWithdrawal();
    });
    
    const optionTabs = modalContent.querySelectorAll('.option-tab');
    optionTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            optionTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            const optionType = tab.dataset.option;
            updateWithdrawalOption(optionType);
        });
    });
    
    // Validação do valor do saque
    const expressAmount = document.getElementById('express-amount');
    expressAmount.addEventListener('input', () => {
        validateWithdrawalAmount('express');
    });
}

// Atualiza a opção de saque selecionada
function updateWithdrawalOption(optionType) {
    const optionContent = document.getElementById('option-content');
    
    if (optionType === 'express') {
        optionContent.innerHTML = `
            <div class="express-option">
                <div class="option-description">
                    <p><strong>Saque Express:</strong> Receba seu dinheiro em até 24 horas.</p>
                    <p class="option-note">Valor mínimo: R$ ${bankingState.withdrawalRules.expressMinimum.toFixed(2)}</p>
                </div>
                
                <div class="form-group">
                    <label for="express-amount">Valor do Saque</label>
                    <input type="number" id="express-amount" class="form-control" min="${bankingState.withdrawalRules.expressMinimum}" max="${bankingState.accountInfo.balance}" step="0.01" value="${Math.max(bankingState.withdrawalRules.expressMinimum, Math.min(bankingState.accountInfo.balance, 100)).toFixed(2)}">
                    <div class="amount-error" id="express-amount-error"></div>
                </div>
            </div>
        `;
        
        // Validação do valor do saque
        const expressAmount = document.getElementById('express-amount');
        expressAmount.addEventListener('input', () => {
            validateWithdrawalAmount('express');
        });
    } else {
        optionContent.innerHTML = `
            <div class="regular-option">
                <div class="option-description">
                    <p><strong>Saque Regular:</strong> Receba seu dinheiro em até ${bankingState.withdrawalRules.regularWaitingDays} dias úteis.</p>
                    <p class="option-note">Sem valor mínimo. Ideal para saques menores.</p>
                </div>
                
                <div class="form-group">
                    <label for="regular-amount">Valor do Saque</label>
                    <input type="number" id="regular-amount" class="form-control" min="1" max="${bankingState.accountInfo.balance}" step="0.01" value="${Math.min(bankingState.accountInfo.balance, 50).toFixed(2)}">
                    <div class="amount-error" id="regular-amount-error"></div>
                </div>
                
                <div class="waiting-period-notice">
                    <div class="notice-icon"><i class="fas fa-info-circle"></i></div>
                    <div class="notice-text">
                        <p>Para saques menores que R$ ${bankingState.withdrawalRules.expressMinimum.toFixed(2)}, o prazo de processamento é de ${bankingState.withdrawalRules.regularWaitingDays} dias úteis.</p>
                        <p>Você também pode completar com outros serviços para atingir o valor mínimo do Saque Express.</p>
                    </div>
                </div>
            </div>
        `;
        
        // Validação do valor do saque
        const regularAmount = document.getElementById('regular-amount');
        regularAmount.addEventListener('input', () => {
            validateWithdrawalAmount('regular');
        });
    }
}

// Valida o valor do saque
function validateWithdrawalAmount(optionType) {
    const amountInput = document.getElementById(`${optionType}-amount`);
    const amountError = document.getElementById(`${optionType}-amount-error`);
    
    const amount = parseFloat(amountInput.value);
    
    if (isNaN(amount) || amount <= 0) {
        amountError.textContent = 'Por favor, insira um valor válido.';
        return false;
    }
    
    if (amount > bankingState.accountInfo.balance) {
        amountError.textContent = 'Valor excede o saldo disponível.';
        return false;
    }
    
    if (optionType === 'express' && amount < bankingState.withdrawalRules.expressMinimum) {
        amountError.textContent = `Valor mínimo para Saque Express: R$ ${bankingState.withdrawalRules.expressMinimum.toFixed(2)}`;
        return false;
    }
    
    amountError.textContent = '';
    return true;
}

// Processa a solicitação de saque
function processWithdrawal() {
    const activeTab = document.querySelector('.option-tab.active');
    const optionType = activeTab.dataset.option;
    
    if (!validateWithdrawalAmount(optionType)) {
        return;
    }
    
    const amountInput = document.getElementById(`${optionType}-amount`);
    const amount = parseFloat(amountInput.value);
    
    const selectedMethod = document.querySelector('input[name="withdrawal-method"]:checked').value;
    
    // Simula o processamento do saque
    const withdrawalDate = new Date();
    const withdrawalId = `WD-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`;
    
    // Adiciona a transação ao histórico
    bankingState.transactions.unshift({
        id: withdrawalId,
        date: withdrawalDate.toISOString().split('T')[0],
        type: 'withdrawal',
        description: `Saque ${optionType === 'express' ? 'Express' : 'Regular'} - ${selectedMethod}`,
        amount: -amount,
        status: 'pending'
    });
    
    // Atualiza o saldo
    bankingState.accountInfo.balance -= amount;
    
    // Atualiza a última retirada
    bankingState.accountInfo.lastWithdrawal = {
        date: withdrawalDate.toISOString().split('T')[0],
        amount: amount,
        status: 'pending'
    };
    
    // Fecha o modal
    const modalOverlay = document.querySelector('.modal-overlay');
    document.body.removeChild(modalOverlay);
    
    // Exibe mensagem de sucesso
    showWithdrawalConfirmation(optionType, amount, selectedMethod);
    
    // Atualiza a interface
    const bankingContainer = document.getElementById('banking-container');
    if (bankingContainer) {
        bankingContainer.innerHTML = '';
        renderBankingUI(bankingContainer);
        attachEventListeners();
    }
}

// Exibe confirmação de saque
function showWithdrawalConfirmation(optionType, amount, method) {
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content confirmation-modal';
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>Saque Solicitado com Sucesso</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="confirmation-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            
            <div class="confirmation-details">
                <p>Sua solicitação de saque foi recebida com sucesso!</p>
                
                <div class="confirmation-info">
                    <div class="info-item">
                        <span class="info-label">Valor:</span>
                        <span class="info-value">R$ ${amount.toFixed(2)}</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Método:</span>
                        <span class="info-value">${method}</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Tipo:</span>
                        <span class="info-value">${optionType === 'express' ? 'Saque Express' : 'Saque Regular'}</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Prazo:</span>
                        <span class="info-value">${optionType === 'express' ? 'Até 24 horas' : `Até ${bankingState.withdrawalRules.regularWaitingDays} dias úteis`}</span>
                    </div>
                </div>
                
                <div class="confirmation-note">
                    <p>Você receberá uma notificação quando o saque for processado.</p>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-primary" id="close-confirmation">Entendi</button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Anexa event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const confirmButton = document.getElementById('close-confirmation');
    confirmButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
}

// Exibe detalhes de um serviço pendente
function showTransferDetailsModal(transfer) {
    // Cria o elemento do modal
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content transfer-details-modal';
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>Detalhes do Serviço</h3>
            <button class="modal-close">&times;</button>
        </div>
        
        <div class="modal-body">
            <div class="transfer-details-info">
                <div class="info-item">
                    <span class="info-label">Serviço:</span>
                    <span class="info-value">${transfer.description}</span>
                </div>
                
                <div class="info-item">
                    <span class="info-label">Data:</span>
                    <span class="info-value">${formatDate(transfer.date)}</span>
                </div>
                
                <div class="info-item">
                    <span class="info-label">Horário:</span>
                    <span class="info-value">${transfer.pickupTime}</span>
                </div>
                
                <div class="info-item">
                    <span class="info-label">Cliente:</span>
                    <span class="info-value">${transfer.client}</span>
                </div>
                
                <div class="info-item">
                    <span class="info-label">Valor:</span>
                    <span class="info-value">R$ ${transfer.amount.toFixed(2)}</span>
                </div>
                
                <div class="info-item">
                    <span class="info-label">Status:</span>
                    <span class="info-value status-${transfer.status}">${transfer.status === 'pending' ? 'Aguardando Confirmação' : 'Confirmado'}</span>
                </div>
            </div>
            
            <div class="transfer-actions-container">
                ${transfer.status === 'pending' ? `
                    <button class="btn-primary" id="confirm-transfer" data-id="${transfer.id}">
                        <i class="fas fa-check"></i> Confirmar Serviço
                    </button>
                ` : `
                    <div class="transfer-confirmed-message">
                        <div class="confirmed-icon"><i class="fas fa-check-circle"></i></div>
                        <p>Este serviço já foi confirmado. Esteja no local de embarque no horário indicado.</p>
                    </div>
                `}
            </div>
        </div>
        
        <div class="modal-footer">
            <button class="btn-secondary" id="close-transfer-details">Fechar</button>
        </div>
    `;
    
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);
    
    // Anexa event listeners
    const closeButton = modalContent.querySelector('.modal-close');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const closeDetailsButton = document.getElementById('close-transfer-details');
    closeDetailsButton.addEventListener('click', () => {
        document.body.removeChild(modalOverlay);
    });
    
    const confirmTransferButton = document.getElementById('confirm-transfer');
    if (confirmTransferButton) {
        confirmTransferButton.addEventListener('click', () => {
            confirmTransfer(transfer.id);
            document.body.removeChild(modalOverlay);
        });
    }
}

// Confirma um serviço pendente
function confirmTransfer(transferId) {
    const transferIndex = bankingState.pendingTransfers.findIndex(t => t.id === transferId);
    
    if (transferIndex !== -1) {
        bankingState.pendingTransfers[transferIndex].status = 'confirmed';
        
        // Atualiza a interface
        const bankingContainer = document.getElementById('banking-container');
        if (bankingContainer) {
            bankingContainer.innerHTML = '';
            renderBankingUI(bankingContainer);
            attachEventListeners();
            
            // Seleciona a aba de serviços pendentes
            const pendingTransfersTab = document.querySelector('.tab[data-tab="pending-transfers"]');
            if (pendingTransfersTab) {
                pendingTransfersTab.click();
            }
        }
    }
}

// Formata data
function formatDate(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Inicializa o sistema bancário quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initBankingSystem();
});
